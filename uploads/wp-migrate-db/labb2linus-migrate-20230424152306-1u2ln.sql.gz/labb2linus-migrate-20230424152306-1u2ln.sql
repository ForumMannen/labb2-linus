# WordPress MySQL database migration
#
# Generated: Monday 24. April 2023 15:23 UTC
# Hostname: localhost
# Database: `labb2-linus`
# URL: //localhost/labb2-linus
# Path: C:\\MAMP\\htdocs\\labb2-linus
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_coupon_lookup, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, post, product, product_variation, shop_coupon
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2023-04-19 13:21:11', '2023-04-19 15:21:11', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681910471;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681910471;s:19:"scheduled_timestamp";i:1681910471;s:9:"timestamp";i:1681910471;}', 1, 1, '2023-04-19 13:21:16', '2023-04-19 15:21:16', 0, NULL),
(7, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-19 13:20:13', '2023-04-19 15:20:13', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1681910413;s:18:"\0*\0first_timestamp";i:1681910413;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1681910413;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1681910413;s:15:"first_timestamp";i:1681910413;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1681910413;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-19 13:21:16', '2023-04-19 15:21:16', 0, NULL),
(8, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-20 13:21:16', '2023-04-20 15:21:16', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1681996876;s:18:"\0*\0first_timestamp";i:1681910413;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1681996876;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1681996876;s:15:"first_timestamp";i:1681910413;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1681996876;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-20 13:21:23', '2023-04-20 15:21:23', 0, NULL),
(9, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-19 13:57:43', '2023-04-19 15:57:43', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681912663;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681912663;s:19:"scheduled_timestamp";i:1681912663;s:9:"timestamp";i:1681912663;}', 2, 1, '2023-04-19 13:58:13', '2023-04-19 15:58:13', 0, NULL),
(10, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:23:02', '2023-04-20 11:23:02', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982582;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982582;s:19:"scheduled_timestamp";i:1681982582;s:9:"timestamp";i:1681982582;}', 2, 1, '2023-04-20 09:23:26', '2023-04-20 11:23:26', 0, NULL),
(11, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:23:42', '2023-04-20 11:23:42', '[26,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982622;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982622;s:19:"scheduled_timestamp";i:1681982622;s:9:"timestamp";i:1681982622;}', 2, 1, '2023-04-20 09:24:26', '2023-04-20 11:24:26', 0, NULL),
(12, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:23:42', '2023-04-20 11:23:42', '[27,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982622;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982622;s:19:"scheduled_timestamp";i:1681982622;s:9:"timestamp";i:1681982622;}', 2, 1, '2023-04-20 09:24:26', '2023-04-20 11:24:26', 0, NULL),
(13, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:23:42', '2023-04-20 11:23:42', '[28,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982622;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982622;s:19:"scheduled_timestamp";i:1681982622;s:9:"timestamp";i:1681982622;}', 2, 1, '2023-04-20 09:24:26', '2023-04-20 11:24:26', 0, NULL),
(14, 'adjust_download_permissions', 'complete', '2023-04-20 09:23:42', '2023-04-20 11:23:42', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982622;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982622;s:19:"scheduled_timestamp";i:1681982622;s:9:"timestamp";i:1681982622;}', 0, 1, '2023-04-20 09:24:26', '2023-04-20 11:24:26', 0, NULL),
(15, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:23:42', '2023-04-20 11:23:42', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982622;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982622;s:19:"scheduled_timestamp";i:1681982622;s:9:"timestamp";i:1681982622;}', 2, 1, '2023-04-20 09:24:26', '2023-04-20 11:24:26', 0, NULL),
(16, 'adjust_download_permissions', 'complete', '2023-04-20 09:28:44', '2023-04-20 11:28:44', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982924;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982924;s:19:"scheduled_timestamp";i:1681982924;s:9:"timestamp";i:1681982924;}', 0, 1, '2023-04-20 09:29:17', '2023-04-20 11:29:17', 0, NULL),
(17, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:28:44', '2023-04-20 11:28:44', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681982924;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681982924;s:19:"scheduled_timestamp";i:1681982924;s:9:"timestamp";i:1681982924;}', 2, 1, '2023-04-20 09:29:17', '2023-04-20 11:29:17', 0, NULL),
(18, 'adjust_download_permissions', 'complete', '2023-04-20 09:43:56', '2023-04-20 11:43:56', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681983836;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681983836;s:19:"scheduled_timestamp";i:1681983836;s:9:"timestamp";i:1681983836;}', 0, 1, '2023-04-20 09:44:10', '2023-04-20 11:44:10', 0, NULL),
(19, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:43:56', '2023-04-20 11:43:56', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681983836;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681983836;s:19:"scheduled_timestamp";i:1681983836;s:9:"timestamp";i:1681983836;}', 2, 1, '2023-04-20 09:44:10', '2023-04-20 11:44:10', 0, NULL),
(20, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:55:42', '2023-04-20 11:55:42', '[26,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984542;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984542;s:19:"scheduled_timestamp";i:1681984542;s:9:"timestamp";i:1681984542;}', 2, 1, '2023-04-20 09:56:12', '2023-04-20 11:56:12', 0, NULL),
(21, 'adjust_download_permissions', 'complete', '2023-04-20 09:55:42', '2023-04-20 11:55:42', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984542;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984542;s:19:"scheduled_timestamp";i:1681984542;s:9:"timestamp";i:1681984542;}', 0, 1, '2023-04-20 09:56:12', '2023-04-20 11:56:12', 0, NULL),
(22, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:55:45', '2023-04-20 11:55:45', '[27,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984545;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984545;s:19:"scheduled_timestamp";i:1681984545;s:9:"timestamp";i:1681984545;}', 2, 1, '2023-04-20 09:56:12', '2023-04-20 11:56:12', 0, NULL),
(23, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:55:48', '2023-04-20 11:55:48', '[28,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984548;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984548;s:19:"scheduled_timestamp";i:1681984548;s:9:"timestamp";i:1681984548;}', 2, 1, '2023-04-20 09:56:12', '2023-04-20 11:56:12', 0, NULL),
(24, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:55:48', '2023-04-20 11:55:48', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984548;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984548;s:19:"scheduled_timestamp";i:1681984548;s:9:"timestamp";i:1681984548;}', 2, 1, '2023-04-20 09:56:12', '2023-04-20 11:56:12', 0, NULL),
(25, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:58:10', '2023-04-20 11:58:10', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984690;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984690;s:19:"scheduled_timestamp";i:1681984690;s:9:"timestamp";i:1681984690;}', 2, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(26, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:58:29', '2023-04-20 11:58:29', '[30,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984709;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984709;s:19:"scheduled_timestamp";i:1681984709;s:9:"timestamp";i:1681984709;}', 2, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(27, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:58:29', '2023-04-20 11:58:29', '[31,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984709;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984709;s:19:"scheduled_timestamp";i:1681984709;s:9:"timestamp";i:1681984709;}', 2, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(28, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:58:29', '2023-04-20 11:58:29', '[32,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984709;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984709;s:19:"scheduled_timestamp";i:1681984709;s:9:"timestamp";i:1681984709;}', 2, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(29, 'adjust_download_permissions', 'complete', '2023-04-20 09:58:29', '2023-04-20 11:58:29', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984709;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984709;s:19:"scheduled_timestamp";i:1681984709;s:9:"timestamp";i:1681984709;}', 0, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(30, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 09:58:29', '2023-04-20 11:58:29', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984709;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984709;s:19:"scheduled_timestamp";i:1681984709;s:9:"timestamp";i:1681984709;}', 2, 1, '2023-04-20 09:59:41', '2023-04-20 11:59:41', 0, NULL),
(31, 'adjust_download_permissions', 'complete', '2023-04-20 10:01:43', '2023-04-20 12:01:43', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984903;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984903;s:19:"scheduled_timestamp";i:1681984903;s:9:"timestamp";i:1681984903;}', 0, 1, '2023-04-20 10:02:29', '2023-04-20 12:02:29', 0, NULL),
(32, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:01:43', '2023-04-20 12:01:43', '[30,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984903;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984903;s:19:"scheduled_timestamp";i:1681984903;s:9:"timestamp";i:1681984903;}', 2, 1, '2023-04-20 10:02:29', '2023-04-20 12:02:29', 0, NULL),
(33, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:01:44', '2023-04-20 12:01:44', '[31,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984904;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984904;s:19:"scheduled_timestamp";i:1681984904;s:9:"timestamp";i:1681984904;}', 2, 1, '2023-04-20 10:02:29', '2023-04-20 12:02:29', 0, NULL),
(34, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:01:44', '2023-04-20 12:01:44', '[32,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984904;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984904;s:19:"scheduled_timestamp";i:1681984904;s:9:"timestamp";i:1681984904;}', 2, 1, '2023-04-20 10:02:29', '2023-04-20 12:02:29', 0, NULL),
(35, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'failed', '2023-04-20 10:02:29', '2023-04-20 10:02:29', '[]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 0, 1, '2023-04-20 10:02:42', '2023-04-20 12:02:42', 0, NULL),
(36, 'adjust_download_permissions', 'complete', '2023-04-20 10:02:30', '2023-04-20 12:02:30', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984950;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984950;s:19:"scheduled_timestamp";i:1681984950;s:9:"timestamp";i:1681984950;}', 0, 1, '2023-04-20 10:02:42', '2023-04-20 12:02:42', 0, NULL),
(37, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:02:30', '2023-04-20 12:02:30', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681984950;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681984950;s:19:"scheduled_timestamp";i:1681984950;s:9:"timestamp";i:1681984950;}', 2, 1, '2023-04-20 10:02:42', '2023-04-20 12:02:42', 0, NULL),
(38, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:10:05', '2023-04-20 12:10:05', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985405;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985405;s:19:"scheduled_timestamp";i:1681985405;s:9:"timestamp";i:1681985405;}', 2, 1, '2023-04-20 10:10:18', '2023-04-20 12:10:18', 0, NULL),
(39, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:10:31', '2023-04-20 12:10:31', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985431;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985431;s:19:"scheduled_timestamp";i:1681985431;s:9:"timestamp";i:1681985431;}', 2, 1, '2023-04-20 10:11:11', '2023-04-20 12:11:11', 0, NULL),
(40, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[34,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(41, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[35,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(42, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[36,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(43, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[37,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(44, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[38,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(45, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[39,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(46, 'adjust_download_permissions', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 0, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(47, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:11:12', '2023-04-20 12:11:12', '[33,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985472;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985472;s:19:"scheduled_timestamp";i:1681985472;s:9:"timestamp";i:1681985472;}', 2, 1, '2023-04-20 10:12:09', '2023-04-20 12:12:09', 0, NULL),
(48, 'adjust_download_permissions', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 0, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(49, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[34,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(50, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[35,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(51, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[36,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(52, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[37,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(53, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[38,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(54, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:18', '2023-04-20 12:17:18', '[39,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985838;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985838;s:19:"scheduled_timestamp";i:1681985838;s:9:"timestamp";i:1681985838;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(55, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:17:38', '2023-04-20 12:17:38', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985858;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985858;s:19:"scheduled_timestamp";i:1681985858;s:9:"timestamp";i:1681985858;}', 2, 1, '2023-04-20 10:18:18', '2023-04-20 12:18:18', 0, NULL),
(56, 'adjust_download_permissions', 'complete', '2023-04-20 10:18:41', '2023-04-20 12:18:41', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985921;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985921;s:19:"scheduled_timestamp";i:1681985921;s:9:"timestamp";i:1681985921;}', 0, 1, '2023-04-20 10:52:25', '2023-04-20 12:52:25', 0, NULL),
(57, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:18:41', '2023-04-20 12:18:41', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985921;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985921;s:19:"scheduled_timestamp";i:1681985921;s:9:"timestamp";i:1681985921;}', 2, 1, '2023-04-20 10:52:26', '2023-04-20 12:52:26', 0, NULL),
(58, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:54:34', '2023-04-20 12:54:34', '[40,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988074;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988074;s:19:"scheduled_timestamp";i:1681988074;s:9:"timestamp";i:1681988074;}', 2, 1, '2023-04-20 10:55:12', '2023-04-20 12:55:12', 0, NULL),
(59, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:47', '2023-04-20 12:55:47', '[41,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988147;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988147;s:19:"scheduled_timestamp";i:1681988147;s:9:"timestamp";i:1681988147;}', 2, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(60, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:55', '2023-04-20 12:55:55', '[42,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988155;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988155;s:19:"scheduled_timestamp";i:1681988155;s:9:"timestamp";i:1681988155;}', 2, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(61, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:55', '2023-04-20 12:55:55', '[43,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988155;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988155;s:19:"scheduled_timestamp";i:1681988155;s:9:"timestamp";i:1681988155;}', 2, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(62, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:55', '2023-04-20 12:55:55', '[44,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988155;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988155;s:19:"scheduled_timestamp";i:1681988155;s:9:"timestamp";i:1681988155;}', 2, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(63, 'adjust_download_permissions', 'complete', '2023-04-20 10:55:55', '2023-04-20 12:55:55', '[41]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988155;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988155;s:19:"scheduled_timestamp";i:1681988155;s:9:"timestamp";i:1681988155;}', 0, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(64, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:55', '2023-04-20 12:55:55', '[41,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988155;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988155;s:19:"scheduled_timestamp";i:1681988155;s:9:"timestamp";i:1681988155;}', 2, 1, '2023-04-20 10:56:12', '2023-04-20 12:56:12', 0, NULL),
(65, 'adjust_download_permissions', 'complete', '2023-04-20 10:59:25', '2023-04-20 12:59:25', '[41]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988365;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988365;s:19:"scheduled_timestamp";i:1681988365;s:9:"timestamp";i:1681988365;}', 0, 1, '2023-04-20 11:00:12', '2023-04-20 13:00:12', 0, NULL),
(66, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:59:25', '2023-04-20 12:59:25', '[42,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988365;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988365;s:19:"scheduled_timestamp";i:1681988365;s:9:"timestamp";i:1681988365;}', 2, 1, '2023-04-20 11:00:12', '2023-04-20 13:00:12', 0, NULL),
(67, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:59:25', '2023-04-20 12:59:25', '[43,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988365;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988365;s:19:"scheduled_timestamp";i:1681988365;s:9:"timestamp";i:1681988365;}', 2, 1, '2023-04-20 11:00:12', '2023-04-20 13:00:12', 0, NULL),
(68, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:59:25', '2023-04-20 12:59:25', '[44,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988365;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988365;s:19:"scheduled_timestamp";i:1681988365;s:9:"timestamp";i:1681988365;}', 2, 1, '2023-04-20 11:00:12', '2023-04-20 13:00:12', 0, NULL),
(69, 'adjust_download_permissions', 'complete', '2023-04-20 11:00:15', '2023-04-20 13:00:15', '[41]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988415;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988415;s:19:"scheduled_timestamp";i:1681988415;s:9:"timestamp";i:1681988415;}', 0, 1, '2023-04-20 11:16:57', '2023-04-20 13:16:57', 0, NULL),
(70, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 11:00:15', '2023-04-20 13:00:15', '[41,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988415;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988415;s:19:"scheduled_timestamp";i:1681988415;s:9:"timestamp";i:1681988415;}', 2, 1, '2023-04-20 11:16:57', '2023-04-20 13:16:57', 0, NULL),
(71, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:18:07', '2023-04-20 15:18:07', '[45,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681996687;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681996687;s:19:"scheduled_timestamp";i:1681996687;s:9:"timestamp";i:1681996687;}', 2, 1, '2023-04-20 13:18:09', '2023-04-20 15:18:09', 0, NULL),
(72, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:18:39', '2023-04-20 15:18:39', '[45,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681996719;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681996719;s:19:"scheduled_timestamp";i:1681996719;s:9:"timestamp";i:1681996719;}', 2, 1, '2023-04-20 13:19:17', '2023-04-20 15:19:17', 0, NULL),
(73, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-21 13:21:23', '2023-04-21 15:21:23', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682083283;s:18:"\0*\0first_timestamp";i:1681910413;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682083283;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682083283;s:15:"first_timestamp";i:1681910413;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682083283;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-24 07:32:23', '2023-04-24 09:32:23', 0, NULL),
(74, 'adjust_download_permissions', 'complete', '2023-04-20 13:29:44', '2023-04-20 15:29:44', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681997384;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681997384;s:19:"scheduled_timestamp";i:1681997384;s:9:"timestamp";i:1681997384;}', 0, 1, '2023-04-20 13:37:42', '2023-04-20 15:37:42', 0, NULL),
(75, 'adjust_download_permissions', 'complete', '2023-04-20 13:57:08', '2023-04-20 15:57:08', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999028;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999028;s:19:"scheduled_timestamp";i:1681999028;s:9:"timestamp";i:1681999028;}', 0, 1, '2023-04-20 13:57:16', '2023-04-20 15:57:16', 0, NULL),
(76, 'adjust_download_permissions', 'complete', '2023-04-20 13:57:17', '2023-04-20 15:57:17', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999037;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999037;s:19:"scheduled_timestamp";i:1681999037;s:9:"timestamp";i:1681999037;}', 0, 1, '2023-04-20 13:57:19', '2023-04-20 15:57:19', 0, NULL),
(77, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:57:17', '2023-04-20 15:57:17', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999037;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999037;s:19:"scheduled_timestamp";i:1681999037;s:9:"timestamp";i:1681999037;}', 2, 1, '2023-04-20 13:57:19', '2023-04-20 15:57:19', 0, NULL),
(78, 'adjust_download_permissions', 'complete', '2023-04-20 13:57:55', '2023-04-20 15:57:55', '[33]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999075;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999075;s:19:"scheduled_timestamp";i:1681999075;s:9:"timestamp";i:1681999075;}', 0, 1, '2023-04-20 13:58:21', '2023-04-20 15:58:21', 0, NULL),
(79, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:57:55', '2023-04-20 15:57:55', '[33,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999075;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999075;s:19:"scheduled_timestamp";i:1681999075;s:9:"timestamp";i:1681999075;}', 2, 1, '2023-04-20 13:58:21', '2023-04-20 15:58:21', 0, NULL),
(80, 'adjust_download_permissions', 'complete', '2023-04-20 13:59:10', '2023-04-20 15:59:10', '[25]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999150;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999150;s:19:"scheduled_timestamp";i:1681999150;s:9:"timestamp";i:1681999150;}', 0, 1, '2023-04-20 18:32:06', '2023-04-20 20:32:06', 0, NULL),
(81, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 13:59:10', '2023-04-20 15:59:10', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681999150;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681999150;s:19:"scheduled_timestamp";i:1681999150;s:9:"timestamp";i:1681999150;}', 2, 1, '2023-04-20 18:32:06', '2023-04-20 20:32:06', 0, NULL),
(82, 'adjust_download_permissions', 'complete', '2023-04-21 07:56:26', '2023-04-21 09:56:26', '[41]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682063786;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682063786;s:19:"scheduled_timestamp";i:1682063786;s:9:"timestamp";i:1682063786;}', 0, 1, '2023-04-21 07:56:35', '2023-04-21 09:56:35', 0, NULL),
(83, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 07:56:26', '2023-04-21 09:56:26', '[41,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682063786;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682063786;s:19:"scheduled_timestamp";i:1682063786;s:9:"timestamp";i:1682063786;}', 2, 1, '2023-04-21 07:56:36', '2023-04-21 09:56:36', 0, NULL),
(84, 'woocommerce_cleanup_draft_orders', 'pending', '2023-04-25 07:32:23', '2023-04-25 09:32:23', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682407943;s:18:"\0*\0first_timestamp";i:1681910413;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682407943;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682407943;s:15:"first_timestamp";i:1681910413;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682407943;s:19:"interval_in_seconds";i:86400;}', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'woocommerce-db-updates') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'action created', '2023-04-19 13:20:11', '2023-04-19 15:20:11'),
(2, 7, 'action created', '2023-04-19 13:20:13', '2023-04-19 15:20:13'),
(3, 7, 'action started via Async Request', '2023-04-19 13:21:16', '2023-04-19 15:21:16'),
(4, 7, 'action complete via Async Request', '2023-04-19 13:21:16', '2023-04-19 15:21:16'),
(5, 8, 'action created', '2023-04-19 13:21:16', '2023-04-19 15:21:16'),
(6, 6, 'action started via Async Request', '2023-04-19 13:21:16', '2023-04-19 15:21:16'),
(7, 6, 'action complete via Async Request', '2023-04-19 13:21:16', '2023-04-19 15:21:16'),
(8, 9, 'action created', '2023-04-19 13:57:42', '2023-04-19 15:57:42'),
(9, 9, 'action started via WP Cron', '2023-04-19 13:58:13', '2023-04-19 15:58:13'),
(10, 9, 'action complete via WP Cron', '2023-04-19 13:58:13', '2023-04-19 15:58:13'),
(11, 10, 'action created', '2023-04-20 09:23:01', '2023-04-20 11:23:01'),
(12, 10, 'action started via WP Cron', '2023-04-20 09:23:26', '2023-04-20 11:23:26'),
(13, 10, 'action complete via WP Cron', '2023-04-20 09:23:26', '2023-04-20 11:23:26'),
(14, 11, 'action created', '2023-04-20 09:23:41', '2023-04-20 11:23:41'),
(15, 12, 'action created', '2023-04-20 09:23:41', '2023-04-20 11:23:41'),
(16, 13, 'action created', '2023-04-20 09:23:41', '2023-04-20 11:23:41'),
(17, 14, 'action created', '2023-04-20 09:23:41', '2023-04-20 11:23:41'),
(18, 15, 'action created', '2023-04-20 09:23:41', '2023-04-20 11:23:41'),
(19, 11, 'action started via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(20, 11, 'action complete via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(21, 12, 'action started via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(22, 12, 'action complete via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(23, 13, 'action started via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(24, 13, 'action complete via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(25, 14, 'action started via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(26, 14, 'action complete via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(27, 15, 'action started via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(28, 15, 'action complete via WP Cron', '2023-04-20 09:24:26', '2023-04-20 11:24:26'),
(29, 16, 'action created', '2023-04-20 09:28:43', '2023-04-20 11:28:43'),
(30, 17, 'action created', '2023-04-20 09:28:43', '2023-04-20 11:28:43'),
(31, 16, 'action started via WP Cron', '2023-04-20 09:29:16', '2023-04-20 11:29:16'),
(32, 16, 'action complete via WP Cron', '2023-04-20 09:29:17', '2023-04-20 11:29:17'),
(33, 17, 'action started via WP Cron', '2023-04-20 09:29:17', '2023-04-20 11:29:17'),
(34, 17, 'action complete via WP Cron', '2023-04-20 09:29:17', '2023-04-20 11:29:17'),
(35, 18, 'action created', '2023-04-20 09:43:55', '2023-04-20 11:43:55'),
(36, 19, 'action created', '2023-04-20 09:43:55', '2023-04-20 11:43:55'),
(37, 18, 'action started via WP Cron', '2023-04-20 09:44:09', '2023-04-20 11:44:09'),
(38, 18, 'action complete via WP Cron', '2023-04-20 09:44:10', '2023-04-20 11:44:10'),
(39, 19, 'action started via WP Cron', '2023-04-20 09:44:10', '2023-04-20 11:44:10'),
(40, 19, 'action complete via WP Cron', '2023-04-20 09:44:10', '2023-04-20 11:44:10'),
(41, 20, 'action created', '2023-04-20 09:55:41', '2023-04-20 11:55:41'),
(42, 21, 'action created', '2023-04-20 09:55:41', '2023-04-20 11:55:41'),
(43, 22, 'action created', '2023-04-20 09:55:44', '2023-04-20 11:55:44'),
(44, 23, 'action created', '2023-04-20 09:55:47', '2023-04-20 11:55:47'),
(45, 24, 'action created', '2023-04-20 09:55:47', '2023-04-20 11:55:47'),
(46, 20, 'action started via WP Cron', '2023-04-20 09:56:11', '2023-04-20 11:56:11'),
(47, 20, 'action complete via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(48, 21, 'action started via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(49, 21, 'action complete via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(50, 22, 'action started via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(51, 22, 'action complete via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(52, 23, 'action started via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(53, 23, 'action complete via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(54, 24, 'action started via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(55, 24, 'action complete via WP Cron', '2023-04-20 09:56:12', '2023-04-20 11:56:12'),
(56, 25, 'action created', '2023-04-20 09:58:09', '2023-04-20 11:58:09'),
(57, 26, 'action created', '2023-04-20 09:58:28', '2023-04-20 11:58:28'),
(58, 27, 'action created', '2023-04-20 09:58:28', '2023-04-20 11:58:28'),
(59, 28, 'action created', '2023-04-20 09:58:28', '2023-04-20 11:58:28'),
(60, 29, 'action created', '2023-04-20 09:58:28', '2023-04-20 11:58:28'),
(61, 30, 'action created', '2023-04-20 09:58:28', '2023-04-20 11:58:28'),
(62, 25, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(63, 25, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(64, 26, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(65, 26, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(66, 27, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(67, 27, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(68, 28, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(69, 28, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(70, 29, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(71, 29, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(72, 30, 'action started via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(73, 30, 'action complete via WP Cron', '2023-04-20 09:59:41', '2023-04-20 11:59:41'),
(74, 31, 'action created', '2023-04-20 10:01:42', '2023-04-20 12:01:42'),
(75, 32, 'action created', '2023-04-20 10:01:42', '2023-04-20 12:01:42'),
(76, 33, 'action created', '2023-04-20 10:01:43', '2023-04-20 12:01:43'),
(77, 34, 'action created', '2023-04-20 10:01:43', '2023-04-20 12:01:43'),
(78, 31, 'action started via WP Cron', '2023-04-20 10:02:28', '2023-04-20 12:02:28'),
(79, 31, 'action complete via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(80, 32, 'action started via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(81, 32, 'action complete via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(82, 33, 'action started via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(83, 33, 'action complete via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(84, 34, 'action started via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(85, 34, 'action complete via WP Cron', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(86, 35, 'action created', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(87, 36, 'action created', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(88, 37, 'action created', '2023-04-20 10:02:29', '2023-04-20 12:02:29'),
(89, 35, 'action started via Async Request', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(90, 35, 'action failed via Async Request: Scheduled action for woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications will not be executed as no callbacks are registered.', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(91, 36, 'action started via Async Request', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(92, 36, 'action complete via Async Request', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(93, 37, 'action started via Async Request', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(94, 37, 'action complete via Async Request', '2023-04-20 10:02:42', '2023-04-20 12:02:42'),
(95, 38, 'action created', '2023-04-20 10:10:04', '2023-04-20 12:10:04'),
(96, 38, 'action started via WP Cron', '2023-04-20 10:10:18', '2023-04-20 12:10:18'),
(97, 38, 'action complete via WP Cron', '2023-04-20 10:10:18', '2023-04-20 12:10:18'),
(98, 39, 'action created', '2023-04-20 10:10:30', '2023-04-20 12:10:30'),
(99, 39, 'action started via WP Cron', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(100, 39, 'action complete via WP Cron', '2023-04-20 10:11:11', '2023-04-20 12:11:11') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(101, 40, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(102, 41, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(103, 42, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(104, 43, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(105, 44, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(106, 45, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(107, 46, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(108, 47, 'action created', '2023-04-20 10:11:11', '2023-04-20 12:11:11'),
(109, 40, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(110, 40, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(111, 41, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(112, 41, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(113, 42, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(114, 42, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(115, 43, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(116, 43, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(117, 44, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(118, 44, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(119, 45, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(120, 45, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(121, 46, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(122, 46, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(123, 47, 'action started via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(124, 47, 'action complete via WP Cron', '2023-04-20 10:12:09', '2023-04-20 12:12:09'),
(125, 48, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(126, 49, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(127, 50, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(128, 51, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(129, 52, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(130, 53, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(131, 54, 'action created', '2023-04-20 10:17:17', '2023-04-20 12:17:17'),
(132, 55, 'action created', '2023-04-20 10:17:37', '2023-04-20 12:17:37'),
(133, 48, 'action started via WP Cron', '2023-04-20 10:18:17', '2023-04-20 12:18:17'),
(134, 48, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(135, 49, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(136, 49, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(137, 50, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(138, 50, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(139, 51, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(140, 51, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(141, 52, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(142, 52, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(143, 53, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(144, 53, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(145, 54, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(146, 54, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(147, 55, 'action started via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(148, 55, 'action complete via WP Cron', '2023-04-20 10:18:18', '2023-04-20 12:18:18'),
(149, 56, 'action created', '2023-04-20 10:18:40', '2023-04-20 12:18:40'),
(150, 57, 'action created', '2023-04-20 10:18:40', '2023-04-20 12:18:40'),
(151, 56, 'action started via WP Cron', '2023-04-20 10:52:25', '2023-04-20 12:52:25'),
(152, 56, 'action complete via WP Cron', '2023-04-20 10:52:25', '2023-04-20 12:52:25'),
(153, 57, 'action started via WP Cron', '2023-04-20 10:52:25', '2023-04-20 12:52:25'),
(154, 57, 'action complete via WP Cron', '2023-04-20 10:52:26', '2023-04-20 12:52:26'),
(155, 58, 'action created', '2023-04-20 10:54:33', '2023-04-20 12:54:33'),
(156, 58, 'action started via WP Cron', '2023-04-20 10:55:12', '2023-04-20 12:55:12'),
(157, 58, 'action complete via WP Cron', '2023-04-20 10:55:12', '2023-04-20 12:55:12'),
(158, 59, 'action created', '2023-04-20 10:55:46', '2023-04-20 12:55:46'),
(159, 60, 'action created', '2023-04-20 10:55:54', '2023-04-20 12:55:54'),
(160, 61, 'action created', '2023-04-20 10:55:54', '2023-04-20 12:55:54'),
(161, 62, 'action created', '2023-04-20 10:55:54', '2023-04-20 12:55:54'),
(162, 63, 'action created', '2023-04-20 10:55:54', '2023-04-20 12:55:54'),
(163, 64, 'action created', '2023-04-20 10:55:54', '2023-04-20 12:55:54'),
(164, 59, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(165, 59, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(166, 60, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(167, 60, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(168, 61, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(169, 61, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(170, 62, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(171, 62, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(172, 63, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(173, 63, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(174, 64, 'action started via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(175, 64, 'action complete via WP Cron', '2023-04-20 10:56:12', '2023-04-20 12:56:12'),
(176, 65, 'action created', '2023-04-20 10:59:24', '2023-04-20 12:59:24'),
(177, 66, 'action created', '2023-04-20 10:59:24', '2023-04-20 12:59:24'),
(178, 67, 'action created', '2023-04-20 10:59:24', '2023-04-20 12:59:24'),
(179, 68, 'action created', '2023-04-20 10:59:24', '2023-04-20 12:59:24'),
(180, 65, 'action started via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(181, 65, 'action complete via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(182, 66, 'action started via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(183, 66, 'action complete via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(184, 67, 'action started via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(185, 67, 'action complete via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(186, 68, 'action started via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(187, 68, 'action complete via WP Cron', '2023-04-20 11:00:12', '2023-04-20 13:00:12'),
(188, 69, 'action created', '2023-04-20 11:00:14', '2023-04-20 13:00:14'),
(189, 70, 'action created', '2023-04-20 11:00:14', '2023-04-20 13:00:14'),
(190, 69, 'action started via WP Cron', '2023-04-20 11:16:57', '2023-04-20 13:16:57'),
(191, 69, 'action complete via WP Cron', '2023-04-20 11:16:57', '2023-04-20 13:16:57'),
(192, 70, 'action started via WP Cron', '2023-04-20 11:16:57', '2023-04-20 13:16:57'),
(193, 70, 'action complete via WP Cron', '2023-04-20 11:16:57', '2023-04-20 13:16:57'),
(194, 71, 'åtgärd skapad', '2023-04-20 13:18:06', '2023-04-20 15:18:06'),
(195, 71, 'åtgärden startades via WP Cron', '2023-04-20 13:18:09', '2023-04-20 15:18:09'),
(196, 71, 'åtgärden slutförd via WP Cron', '2023-04-20 13:18:09', '2023-04-20 15:18:09'),
(197, 72, 'åtgärd skapad', '2023-04-20 13:18:38', '2023-04-20 15:18:38'),
(198, 72, 'åtgärden startades via WP Cron', '2023-04-20 13:19:17', '2023-04-20 15:19:17'),
(199, 72, 'åtgärden slutförd via WP Cron', '2023-04-20 13:19:17', '2023-04-20 15:19:17'),
(200, 8, 'åtgärden startades via WP Cron', '2023-04-20 13:21:23', '2023-04-20 15:21:23') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(201, 8, 'åtgärden slutförd via WP Cron', '2023-04-20 13:21:23', '2023-04-20 15:21:23'),
(202, 73, 'åtgärd skapad', '2023-04-20 13:21:23', '2023-04-20 15:21:23'),
(203, 74, 'åtgärd skapad', '2023-04-20 13:29:43', '2023-04-20 15:29:43'),
(204, 74, 'åtgärden startades via WP Cron', '2023-04-20 13:37:42', '2023-04-20 15:37:42'),
(205, 74, 'åtgärden slutförd via WP Cron', '2023-04-20 13:37:42', '2023-04-20 15:37:42'),
(206, 75, 'åtgärd skapad', '2023-04-20 13:57:07', '2023-04-20 15:57:07'),
(207, 75, 'åtgärden startades via WP Cron', '2023-04-20 13:57:16', '2023-04-20 15:57:16'),
(208, 75, 'åtgärden slutförd via WP Cron', '2023-04-20 13:57:16', '2023-04-20 15:57:16'),
(209, 76, 'åtgärd skapad', '2023-04-20 13:57:16', '2023-04-20 15:57:16'),
(210, 77, 'åtgärd skapad', '2023-04-20 13:57:16', '2023-04-20 15:57:16'),
(211, 76, 'åtgärden startades via Async Request', '2023-04-20 13:57:19', '2023-04-20 15:57:19'),
(212, 76, 'åtgärden slutförd via Async Request', '2023-04-20 13:57:19', '2023-04-20 15:57:19'),
(213, 77, 'åtgärden startades via Async Request', '2023-04-20 13:57:19', '2023-04-20 15:57:19'),
(214, 77, 'åtgärden slutförd via Async Request', '2023-04-20 13:57:19', '2023-04-20 15:57:19'),
(215, 78, 'åtgärd skapad', '2023-04-20 13:57:54', '2023-04-20 15:57:54'),
(216, 79, 'åtgärd skapad', '2023-04-20 13:57:54', '2023-04-20 15:57:54'),
(217, 78, 'åtgärden startades via WP Cron', '2023-04-20 13:58:21', '2023-04-20 15:58:21'),
(218, 78, 'åtgärden slutförd via WP Cron', '2023-04-20 13:58:21', '2023-04-20 15:58:21'),
(219, 79, 'åtgärden startades via WP Cron', '2023-04-20 13:58:21', '2023-04-20 15:58:21'),
(220, 79, 'åtgärden slutförd via WP Cron', '2023-04-20 13:58:21', '2023-04-20 15:58:21'),
(221, 80, 'åtgärd skapad', '2023-04-20 13:59:09', '2023-04-20 15:59:09'),
(222, 81, 'åtgärd skapad', '2023-04-20 13:59:09', '2023-04-20 15:59:09'),
(223, 80, 'åtgärden startades via WP Cron', '2023-04-20 18:32:06', '2023-04-20 20:32:06'),
(224, 80, 'åtgärden slutförd via WP Cron', '2023-04-20 18:32:06', '2023-04-20 20:32:06'),
(225, 81, 'åtgärden startades via WP Cron', '2023-04-20 18:32:06', '2023-04-20 20:32:06'),
(226, 81, 'åtgärden slutförd via WP Cron', '2023-04-20 18:32:06', '2023-04-20 20:32:06'),
(227, 82, 'åtgärd skapad', '2023-04-21 07:56:25', '2023-04-21 09:56:25'),
(228, 83, 'åtgärd skapad', '2023-04-21 07:56:25', '2023-04-21 09:56:25'),
(229, 82, 'åtgärden startades via Async Request', '2023-04-21 07:56:35', '2023-04-21 09:56:35'),
(230, 82, 'åtgärden slutförd via Async Request', '2023-04-21 07:56:35', '2023-04-21 09:56:35'),
(231, 83, 'åtgärden startades via Async Request', '2023-04-21 07:56:35', '2023-04-21 09:56:35'),
(232, 83, 'åtgärden slutförd via Async Request', '2023-04-21 07:56:35', '2023-04-21 09:56:35'),
(233, 73, 'åtgärden startades via WP Cron', '2023-04-24 07:32:23', '2023-04-24 09:32:23'),
(234, 73, 'åtgärden slutförd via WP Cron', '2023-04-24 07:32:23', '2023-04-24 09:32:23'),
(235, 84, 'åtgärd skapad', '2023-04-24 07:32:23', '2023-04-24 09:32:23') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'En kommentarsförfattare', 'wapuu@wordpress.example', 'https://sv.wordpress.org/', '', '2023-04-19 15:03:25', '2023-04-19 13:03:25', 'Hej, det här är en kommentar.\nFör att komma igång med granskning, redigering och borttagning av kommentarer, gå till vyn ”Kommentarer” i adminpanelen.\nKommentarsförfattares profilbilder kommer från <a href="https://sv.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/labb2-linus', 'yes'),
(2, 'home', 'http://localhost/labb2-linus', 'yes'),
(3, 'blogname', 'labb2-linus', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'lundell.linus@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'Y-m-d H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:159:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:28:"labb2-linus/labb2-plugin.php";i:1;s:27:"woocommerce/woocommerce.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'storefront', 'yes'),
(41, 'stylesheet', 'storefront-child', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'Europe/Stockholm', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1697461405', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'sv_SE', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:159:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste inläggen</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:231:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste kommentarer</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:143:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arkiv</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Kategorier</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:17:{i:1682349848;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1682352205;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682352875;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1682353210;a:3:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682353217;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682364010;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682373600;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682384605;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682384620;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682427805;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682427820;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682428810;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682428820;a:2:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682429476;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682600605;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1683206470;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:0:{}', 'yes'),
(123, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1681910483;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(126, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:28:"HTTPS-begäran misslyckades.";}}', 'yes'),
(137, 'can_compress_scripts', '0', 'no'),
(153, 'dismissed_update_core', 'a:1:{s:9:"6.2|sv_SE";b:1;}', 'no'),
(159, 'finished_updating_comment_type', '1', 'yes'),
(160, 'recently_activated', 'a:0:{}', 'yes'),
(165, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(166, 'schema-ActionScheduler_StoreSchema', '6.0.1681910408', 'yes'),
(167, 'schema-ActionScheduler_LoggerSchema', '3.0.1681910408', 'yes'),
(170, 'woocommerce_schema_version', '430', 'yes'),
(171, 'woocommerce_store_address', 'Någon gata 123', 'yes'),
(172, 'woocommerce_store_address_2', '', 'yes'),
(173, 'woocommerce_store_city', 'Någonstans', 'yes'),
(174, 'woocommerce_default_country', 'SE', 'yes'),
(175, 'woocommerce_store_postcode', '12345', 'yes'),
(176, 'woocommerce_allowed_countries', 'all', 'yes'),
(177, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(178, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(179, 'woocommerce_ship_to_countries', '', 'yes'),
(180, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(181, 'woocommerce_default_customer_address', 'base', 'yes'),
(182, 'woocommerce_calc_taxes', 'yes', 'yes'),
(183, 'woocommerce_enable_coupons', 'yes', 'yes'),
(184, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(185, 'woocommerce_currency', 'SEK', 'yes'),
(186, 'woocommerce_currency_pos', 'right_space', 'yes'),
(187, 'woocommerce_price_thousand_sep', '', 'yes'),
(188, 'woocommerce_price_decimal_sep', ',', 'yes'),
(189, 'woocommerce_price_num_decimals', '0', 'yes'),
(190, 'woocommerce_shop_page_id', '6', 'yes'),
(191, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(192, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(193, 'woocommerce_placeholder_image', '5', 'yes'),
(194, 'woocommerce_weight_unit', 'kg', 'yes'),
(195, 'woocommerce_dimension_unit', 'cm', 'yes'),
(196, 'woocommerce_enable_reviews', 'yes', 'yes'),
(197, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(198, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(199, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(200, 'woocommerce_review_rating_required', 'yes', 'no'),
(201, 'woocommerce_manage_stock', 'yes', 'yes'),
(202, 'woocommerce_hold_stock_minutes', '60', 'no'),
(203, 'woocommerce_notify_low_stock', 'yes', 'no'),
(204, 'woocommerce_notify_no_stock', 'yes', 'no'),
(205, 'woocommerce_stock_email_recipient', 'lundell.linus@gmail.com', 'no'),
(206, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(207, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(208, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(209, 'woocommerce_stock_format', '', 'yes'),
(210, 'woocommerce_file_download_method', 'force', 'no'),
(211, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(212, 'woocommerce_downloads_require_login', 'no', 'no'),
(213, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(214, 'woocommerce_downloads_deliver_inline', '', 'no'),
(215, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(216, 'woocommerce_attribute_lookup_enabled', 'no', 'yes'),
(217, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(218, 'woocommerce_prices_include_tax', 'yes', 'yes'),
(219, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(220, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(221, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(222, 'woocommerce_tax_classes', '', 'yes'),
(223, 'woocommerce_tax_display_shop', 'incl', 'yes'),
(224, 'woocommerce_tax_display_cart', 'incl', 'yes'),
(225, 'woocommerce_price_display_suffix', '', 'yes'),
(226, 'woocommerce_tax_total_display', 'itemized', 'no'),
(227, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(228, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(229, 'woocommerce_ship_to_destination', 'billing', 'no'),
(230, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(231, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(232, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(233, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(234, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(235, 'woocommerce_registration_generate_username', 'yes', 'no'),
(236, 'woocommerce_registration_generate_password', 'yes', 'no'),
(237, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(238, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(239, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(240, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(241, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(242, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(243, 'woocommerce_trash_pending_orders', '', 'no'),
(244, 'woocommerce_trash_failed_orders', '', 'no'),
(245, 'woocommerce_trash_cancelled_orders', '', 'no'),
(246, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(247, 'woocommerce_email_from_name', 'labb2-linus', 'no'),
(248, 'woocommerce_email_from_address', 'lundell.linus@gmail.com', 'no'),
(249, 'woocommerce_email_header_image', '', 'no'),
(250, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(251, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(252, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(253, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(254, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(255, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(256, 'woocommerce_cart_page_id', '7', 'no'),
(257, 'woocommerce_checkout_page_id', '8', 'no'),
(258, 'woocommerce_myaccount_page_id', '9', 'no'),
(259, 'woocommerce_terms_page_id', '', 'no'),
(260, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(261, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(262, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(263, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(264, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(265, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(266, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(267, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(268, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(269, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(270, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(271, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(272, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(273, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(274, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(275, 'woocommerce_api_enabled', 'no', 'yes'),
(276, 'woocommerce_allow_tracking', 'no', 'no'),
(277, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(278, 'woocommerce_analytics_enabled', 'yes', 'yes'),
(279, 'woocommerce_navigation_enabled', 'no', 'yes'),
(280, 'woocommerce_new_product_management_enabled', 'no', 'yes'),
(281, 'woocommerce_feature_custom_order_tables_enabled', 'no', 'yes'),
(282, 'woocommerce_single_image_width', '600', 'yes'),
(283, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(284, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(285, 'woocommerce_demo_store', 'no', 'no'),
(286, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(287, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(288, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(289, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(292, 'default_product_cat', '15', 'yes'),
(294, 'woocommerce_refund_returns_page_id', '10', 'yes'),
(297, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:23:"lundell.linus@gmail.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:23:"lundell.linus@gmail.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(298, 'woocommerce_version', '7.6.0', 'yes'),
(299, 'woocommerce_db_version', '7.6.0', 'yes'),
(300, 'woocommerce_admin_install_timestamp', '1681910410', 'yes'),
(301, 'woocommerce_inbox_variant_assignment', '6', 'yes'),
(306, 'action_scheduler_lock_async-request-runner', '1682349754', 'yes'),
(307, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:"no_secure_connection";}', 'yes'),
(308, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"6SudjTHzwKNiK2yb3YmkuzDeACbJbLEe";}', 'yes'),
(310, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(311, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(312, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(313, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(314, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(315, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(316, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(317, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(318, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(319, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(320, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(321, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(331, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'no'),
(337, 'wc_blocks_db_schema_version', '260', 'yes'),
(351, 'woocommerce_task_list_tracked_completed_tasks', 'a:7:{i:0;s:8:"purchase";i:1;s:13:"store_details";i:2;s:8:"shipping";i:3;s:8:"products";i:4;s:15:"review-shipping";i:5;s:3:"tax";i:6;s:8:"payments";}', 'yes'),
(359, 'woocommerce_onboarding_profile', 'a:11:{s:18:"is_agree_marketing";b:0;s:11:"store_email";s:23:"lundell.linus@gmail.com";s:20:"is_store_country_set";b:1;s:8:"industry";a:2:{i:0;a:1:{s:4:"slug";s:27:"fashion-apparel-accessories";}i:1;a:1:{s:4:"slug";s:13:"health-beauty";}}s:13:"product_types";a:2:{i:0;s:8:"physical";i:1;s:9:"downloads";}s:13:"product_count";s:4:"1-10";s:14:"selling_venues";s:2:"no";s:12:"setup_client";b:0;s:19:"business_extensions";a:0:{}s:5:"theme";s:10:"storefront";s:9:"completed";b:1;}', 'yes'),
(360, 'woocommerce_task_list_dismissed_tasks', 'a:0:{}', 'yes'),
(361, 'action_scheduler_migration_status', 'complete', 'yes'),
(367, 'current_theme', 'Storefront Childtheme', 'yes'),
(368, 'theme_switched', '', 'yes'),
(369, 'theme_mods_storefront', 'a:3:{s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1681997904;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes'),
(370, 'woocommerce_catalog_rows', '4', 'yes'),
(371, 'woocommerce_catalog_columns', '3', 'yes'),
(372, 'woocommerce_maybe_regenerate_images_hash', '27acde77266b4d2a3491118955cb3f66', 'yes'),
(374, 'storefront_nux_fresh_site', '0', 'yes'),
(381, 'woocommerce_admin_created_default_shipping_zones', 'yes', 'yes'),
(383, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(617, 'woocommerce_ces_product_feedback_shown', '1', 'yes'),
(705, 'woocommerce_admin_reviewed_default_shipping_zones', 'yes', 'yes'),
(722, 'woocommerce_free_shipping_1_settings', 'a:4:{s:5:"title";s:9:"Fri frakt";s:8:"requires";s:10:"min_amount";s:10:"min_amount";s:3:"299";s:16:"ignore_discounts";s:2:"no";}', 'yes'),
(732, 'category_children', 'a:0:{}', 'yes'),
(751, 'woocommerce_cod_settings', 'a:6:{s:7:"enabled";s:3:"yes";s:5:"title";s:16:"Cash on delivery";s:11:"description";s:28:"Pay with cash upon delivery.";s:12:"instructions";s:28:"Pay with cash upon delivery.";s:18:"enable_for_methods";s:0:"";s:18:"enable_for_virtual";s:3:"yes";}', 'yes'),
(769, 'woocommerce_flat_rate_2_settings', 'a:8:{s:5:"title";s:9:"Fast pris";s:10:"tax_status";s:7:"taxable";s:4:"cost";s:2:"49";s:11:"class_costs";s:0:"";s:13:"class_cost_30";s:0:"";s:13:"class_cost_31";s:2:"49";s:13:"no_class_cost";s:0:"";s:4:"type";s:5:"class";}', 'yes'),
(781, 'new_admin_email', 'lundell.linus@gmail.com', 'yes'),
(857, 'product_cat_children', 'a:2:{i:24;a:2:{i:0;i:26;i:1;i:27;}i:25;a:2:{i:0;i:28;i:1;i:29;}}', 'yes'),
(900, 'theme_mods_storefront-child', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:9:"undermeny";i:33;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(1003, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(1129, 'woocommerce_marketing_overview_welcome_hidden', 'yes', 'yes'),
(1264, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1682349786;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=513 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', 'woocommerce-placeholder.png'),
(4, 5, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"woocommerce-placeholder-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28117;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2314;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"woocommerce-placeholder-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46064;}s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12560;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92182;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4228;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58715;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(9, 14, '_wp_attached_file', '2023/04/handel_2kg.png'),
(10, 14, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/handel_2kg.png";s:8:"filesize";i:535037;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"handel_2kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39799;}s:5:"large";a:5:{s:4:"file";s:24:"handel_2kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:324232;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"handel_2kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12402;}s:12:"medium_large";a:5:{s:4:"file";s:22:"handel_2kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:307459;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"handel_2kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64512;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"handel_2kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98816;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"handel_2kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6027;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(11, 15, '_wp_attached_file', '2023/04/hantel_4kg.png'),
(12, 15, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/hantel_4kg.png";s:8:"filesize";i:504002;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"hantel_4kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41002;}s:5:"large";a:5:{s:4:"file";s:24:"hantel_4kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:308611;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"hantel_4kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13241;}s:12:"medium_large";a:5:{s:4:"file";s:22:"hantel_4kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:299992;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"hantel_4kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64369;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"hantel_4kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98422;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"hantel_4kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6403;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(13, 16, '_wp_attached_file', '2023/04/hantel_5kg.png'),
(14, 16, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/hantel_5kg.png";s:8:"filesize";i:533423;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"hantel_5kg-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:43186;}s:5:"large";a:5:{s:4:"file";s:24:"hantel_5kg-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:316065;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"hantel_5kg-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14039;}s:12:"medium_large";a:5:{s:4:"file";s:22:"hantel_5kg-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:306097;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"hantel_5kg-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66176;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"hantel_5kg-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:100919;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"hantel_5kg-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6808;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(21, 20, '_wp_attached_file', '2023/04/yogamatta.png'),
(22, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:21:"2023/04/yogamatta.png";s:8:"filesize";i:1399465;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:21:"yogamatta-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77953;}s:5:"large";a:5:{s:4:"file";s:23:"yogamatta-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:800250;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"yogamatta-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21018;}s:12:"medium_large";a:5:{s:4:"file";s:21:"yogamatta-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:572047;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"yogamatta-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:105623;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"yogamatta-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:172853;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"yogamatta-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9796;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(23, 21, '_wp_attached_file', '2023/04/yogamatta_pink.png'),
(24, 21, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:26:"2023/04/yogamatta_pink.png";s:8:"filesize";i:1317118;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:26:"yogamatta_pink-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77176;}s:5:"large";a:5:{s:4:"file";s:28:"yogamatta_pink-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:720790;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"yogamatta_pink-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:20741;}s:12:"medium_large";a:5:{s:4:"file";s:26:"yogamatta_pink-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:528217;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"yogamatta_pink-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:104598;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"yogamatta_pink-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:168683;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"yogamatta_pink-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9659;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(25, 22, '_wp_attached_file', '2023/04/Traningsschema.png'),
(26, 22, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1414;s:6:"height";i:2000;s:4:"file";s:26:"2023/04/Traningsschema.png";s:8:"filesize";i:2314129;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:26:"Traningsschema-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:88179;}s:5:"large";a:5:{s:4:"file";s:27:"Traningsschema-724x1024.png";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:729608;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"Traningsschema-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35019;}s:12:"medium_large";a:5:{s:4:"file";s:27:"Traningsschema-768x1086.png";s:5:"width";i:768;s:6:"height";i:1086;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:818028;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Traningsschema-1086x1536.png";s:5:"width";i:1086;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1521261;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:26:"Traningsschema-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:128105;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:26:"Traningsschema-416x588.png";s:5:"width";i:416;s:6:"height";i:588;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:276984;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:26:"Traningsschema-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:17561;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(27, 23, '_wp_attached_file', '2023/04/TraningsschemaPDF.pdf'),
(28, 23, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:474922;}'),
(29, 25, '_edit_last', '1'),
(30, 25, '_edit_lock', '1681999016:1'),
(32, 25, 'total_sales', '0'),
(33, 25, '_tax_status', 'taxable'),
(34, 25, '_tax_class', ''),
(35, 25, '_manage_stock', 'no'),
(36, 25, '_backorders', 'no'),
(37, 25, '_sold_individually', 'no'),
(38, 25, '_virtual', 'no'),
(39, 25, '_downloadable', 'no'),
(40, 25, '_download_limit', '-1'),
(41, 25, '_download_expiry', '-1'),
(42, 25, '_stock', NULL),
(43, 25, '_stock_status', 'instock'),
(44, 25, '_wc_average_rating', '0'),
(45, 25, '_wc_review_count', '0'),
(46, 25, '_product_version', '7.6.0'),
(47, 25, '_product_attributes', 'a:1:{s:10:"pa_storlek";a:6:{s:4:"name";s:10:"pa_storlek";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(100, 30, '_variation_description', ''),
(101, 30, 'total_sales', '0'),
(102, 30, '_tax_status', 'taxable'),
(103, 30, '_tax_class', 'parent'),
(104, 30, '_manage_stock', 'yes'),
(105, 30, '_backorders', 'no'),
(106, 30, '_sold_individually', 'no'),
(107, 30, '_virtual', 'no'),
(108, 30, '_downloadable', 'no'),
(109, 30, '_download_limit', '-1'),
(110, 30, '_download_expiry', '-1'),
(111, 30, '_stock', '7'),
(112, 30, '_stock_status', 'instock'),
(113, 30, '_wc_average_rating', '0'),
(114, 30, '_wc_review_count', '0'),
(115, 30, 'attribute_pa_storlek', 'large'),
(116, 30, '_product_version', '7.6.0'),
(117, 31, '_variation_description', ''),
(118, 31, 'total_sales', '0'),
(119, 31, '_tax_status', 'taxable'),
(120, 31, '_tax_class', 'parent'),
(121, 31, '_manage_stock', 'yes'),
(122, 31, '_backorders', 'no'),
(123, 31, '_sold_individually', 'no'),
(124, 31, '_virtual', 'no'),
(125, 31, '_downloadable', 'no'),
(126, 31, '_download_limit', '-1'),
(127, 31, '_download_expiry', '-1'),
(128, 31, '_stock', '3'),
(129, 31, '_stock_status', 'instock'),
(130, 31, '_wc_average_rating', '0'),
(131, 31, '_wc_review_count', '0'),
(132, 31, 'attribute_pa_storlek', 'medium'),
(133, 31, '_product_version', '7.6.0'),
(134, 32, '_variation_description', ''),
(135, 32, 'total_sales', '0'),
(136, 32, '_tax_status', 'taxable'),
(137, 32, '_tax_class', 'parent'),
(138, 32, '_manage_stock', 'yes'),
(139, 32, '_backorders', 'no'),
(140, 32, '_sold_individually', 'no'),
(141, 32, '_virtual', 'no'),
(142, 32, '_downloadable', 'no'),
(143, 32, '_download_limit', '-1'),
(144, 32, '_download_expiry', '-1'),
(145, 32, '_stock', '9'),
(146, 32, '_stock_status', 'instock'),
(147, 32, '_wc_average_rating', '0'),
(148, 32, '_wc_review_count', '0'),
(149, 32, 'attribute_pa_storlek', 'small'),
(150, 32, '_product_version', '7.6.0'),
(151, 30, '_sku', 'yogatights-large'),
(152, 30, '_regular_price', '399'),
(153, 30, '_thumbnail_id', '0'),
(154, 30, '_price', '399'),
(155, 31, '_sku', 'yogatights-medium'),
(156, 31, '_regular_price', '399'),
(157, 31, '_thumbnail_id', '0'),
(158, 31, '_price', '399'),
(159, 32, '_sku', 'yogatights-small'),
(160, 32, '_regular_price', '399'),
(161, 32, '_thumbnail_id', '0'),
(162, 32, '_price', '399'),
(163, 25, '_price', '399') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(164, 33, '_edit_last', '1'),
(165, 33, '_edit_lock', '1681998936:1'),
(166, 33, 'total_sales', '0'),
(167, 33, '_tax_status', 'taxable'),
(168, 33, '_tax_class', ''),
(169, 33, '_manage_stock', 'no'),
(170, 33, '_backorders', 'no'),
(171, 33, '_sold_individually', 'no'),
(172, 33, '_virtual', 'no'),
(173, 33, '_downloadable', 'no'),
(174, 33, '_download_limit', '-1'),
(175, 33, '_download_expiry', '-1'),
(176, 33, '_stock', NULL),
(177, 33, '_stock_status', 'instock'),
(178, 33, '_wc_average_rating', '0'),
(179, 33, '_wc_review_count', '0'),
(180, 33, '_product_attributes', 'a:2:{s:7:"pa_farg";a:6:{s:4:"name";s:7:"pa_farg";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}s:10:"pa_storlek";a:6:{s:4:"name";s:10:"pa_storlek";s:5:"value";s:0:"";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(181, 33, '_product_version', '7.6.0'),
(182, 34, '_variation_description', ''),
(183, 34, 'total_sales', '0'),
(184, 34, '_tax_status', 'taxable'),
(185, 34, '_tax_class', 'parent'),
(186, 34, '_manage_stock', 'yes'),
(187, 34, '_backorders', 'no'),
(188, 34, '_sold_individually', 'no'),
(189, 34, '_virtual', 'no'),
(190, 34, '_downloadable', 'no'),
(191, 34, '_download_limit', '-1'),
(192, 34, '_download_expiry', '-1'),
(193, 34, '_stock', '3'),
(194, 34, '_stock_status', 'instock'),
(195, 34, '_wc_average_rating', '0'),
(196, 34, '_wc_review_count', '0'),
(197, 34, 'attribute_pa_storlek', 'large'),
(198, 34, 'attribute_pa_farg', 'rosa'),
(199, 34, '_product_version', '7.6.0'),
(200, 35, '_variation_description', ''),
(201, 35, 'total_sales', '0'),
(202, 35, '_tax_status', 'taxable'),
(203, 35, '_tax_class', 'parent'),
(204, 35, '_manage_stock', 'yes'),
(205, 35, '_backorders', 'no'),
(206, 35, '_sold_individually', 'no'),
(207, 35, '_virtual', 'no'),
(208, 35, '_downloadable', 'no'),
(209, 35, '_download_limit', '-1'),
(210, 35, '_download_expiry', '-1'),
(211, 35, '_stock', '3'),
(212, 35, '_stock_status', 'instock'),
(213, 35, '_wc_average_rating', '0'),
(214, 35, '_wc_review_count', '0'),
(215, 35, 'attribute_pa_storlek', 'medium'),
(216, 35, 'attribute_pa_farg', 'rosa'),
(217, 35, '_product_version', '7.6.0'),
(218, 36, '_variation_description', ''),
(219, 36, 'total_sales', '0'),
(220, 36, '_tax_status', 'taxable'),
(221, 36, '_tax_class', 'parent'),
(222, 36, '_manage_stock', 'yes'),
(223, 36, '_backorders', 'no'),
(224, 36, '_sold_individually', 'no'),
(225, 36, '_virtual', 'no'),
(226, 36, '_downloadable', 'no'),
(227, 36, '_download_limit', '-1'),
(228, 36, '_download_expiry', '-1'),
(229, 36, '_stock', '9'),
(230, 36, '_stock_status', 'instock'),
(231, 36, '_wc_average_rating', '0'),
(232, 36, '_wc_review_count', '0'),
(233, 36, 'attribute_pa_storlek', 'small'),
(234, 36, 'attribute_pa_farg', 'rosa'),
(235, 36, '_product_version', '7.6.0'),
(236, 37, '_variation_description', ''),
(237, 37, 'total_sales', '0'),
(238, 37, '_tax_status', 'taxable'),
(239, 37, '_tax_class', 'parent'),
(240, 37, '_manage_stock', 'yes'),
(241, 37, '_backorders', 'no'),
(242, 37, '_sold_individually', 'no'),
(243, 37, '_virtual', 'no'),
(244, 37, '_downloadable', 'no'),
(245, 37, '_download_limit', '-1'),
(246, 37, '_download_expiry', '-1'),
(247, 37, '_stock', '3'),
(248, 37, '_stock_status', 'instock'),
(249, 37, '_wc_average_rating', '0'),
(250, 37, '_wc_review_count', '0'),
(251, 37, 'attribute_pa_storlek', 'large'),
(252, 37, 'attribute_pa_farg', 'svart'),
(253, 37, '_product_version', '7.6.0'),
(254, 38, '_variation_description', ''),
(255, 38, 'total_sales', '0'),
(256, 38, '_tax_status', 'taxable'),
(257, 38, '_tax_class', 'parent'),
(258, 38, '_manage_stock', 'yes'),
(259, 38, '_backorders', 'no'),
(260, 38, '_sold_individually', 'no'),
(261, 38, '_virtual', 'no'),
(262, 38, '_downloadable', 'no'),
(263, 38, '_download_limit', '-1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(264, 38, '_download_expiry', '-1'),
(265, 38, '_stock', '2'),
(266, 38, '_stock_status', 'instock'),
(267, 38, '_wc_average_rating', '0'),
(268, 38, '_wc_review_count', '0'),
(269, 38, 'attribute_pa_storlek', 'medium'),
(270, 38, 'attribute_pa_farg', 'svart'),
(271, 38, '_product_version', '7.6.0'),
(272, 39, '_variation_description', ''),
(273, 39, 'total_sales', '0'),
(274, 39, '_tax_status', 'taxable'),
(275, 39, '_tax_class', 'parent'),
(276, 39, '_manage_stock', 'yes'),
(277, 39, '_backorders', 'no'),
(278, 39, '_sold_individually', 'no'),
(279, 39, '_virtual', 'no'),
(280, 39, '_downloadable', 'no'),
(281, 39, '_download_limit', '-1'),
(282, 39, '_download_expiry', '-1'),
(283, 39, '_stock', '11'),
(284, 39, '_stock_status', 'instock'),
(285, 39, '_wc_average_rating', '0'),
(286, 39, '_wc_review_count', '0'),
(287, 39, 'attribute_pa_storlek', 'small'),
(288, 39, 'attribute_pa_farg', 'svart'),
(289, 39, '_product_version', '7.6.0'),
(292, 33, '_default_attributes', 'a:2:{s:7:"pa_farg";s:4:"rosa";s:10:"pa_storlek";s:5:"small";}'),
(293, 34, '_sku', 'traningstopp-pink-large'),
(294, 34, '_regular_price', '399'),
(296, 34, '_price', '399'),
(297, 35, '_sku', 'traningstopp-pink-medium'),
(298, 35, '_regular_price', '399'),
(300, 35, '_price', '399'),
(301, 36, '_sku', 'traningstopp-pink-small'),
(302, 36, '_regular_price', '399'),
(304, 36, '_price', '399'),
(305, 37, '_sku', 'traningstopp-black-large'),
(306, 37, '_regular_price', '399'),
(308, 37, '_price', '299'),
(309, 38, '_sku', 'traningstopp-black-medium'),
(310, 38, '_regular_price', '399'),
(312, 38, '_price', '299'),
(313, 39, '_sku', 'traningstopp-black-small'),
(314, 39, '_regular_price', '399'),
(316, 39, '_price', '299'),
(319, 20, '_wp_attachment_image_alt', 'yogamatta'),
(320, 40, '_edit_last', '1'),
(321, 40, '_edit_lock', '1681987938:1'),
(322, 40, '_thumbnail_id', '20'),
(323, 40, '_sku', 'yogamatta'),
(324, 40, '_regular_price', '399'),
(325, 40, 'total_sales', '0'),
(326, 40, '_tax_status', 'taxable'),
(327, 40, '_tax_class', ''),
(328, 40, '_manage_stock', 'yes'),
(329, 40, '_backorders', 'no'),
(330, 40, '_sold_individually', 'no'),
(331, 40, '_virtual', 'no'),
(332, 40, '_downloadable', 'no'),
(333, 40, '_download_limit', '-1'),
(334, 40, '_download_expiry', '-1'),
(335, 40, '_stock', '5'),
(336, 40, '_stock_status', 'instock'),
(337, 40, '_wc_average_rating', '0'),
(338, 40, '_wc_review_count', '0'),
(339, 40, '_product_version', '7.6.0'),
(340, 40, '_price', '399'),
(341, 41, '_edit_last', '1'),
(342, 41, '_edit_lock', '1682063650:1'),
(343, 41, 'total_sales', '0'),
(344, 41, '_tax_status', 'taxable'),
(345, 41, '_tax_class', ''),
(346, 41, '_manage_stock', 'no'),
(347, 41, '_backorders', 'no'),
(348, 41, '_sold_individually', 'no'),
(349, 41, '_virtual', 'no'),
(350, 41, '_downloadable', 'no'),
(351, 41, '_download_limit', '-1'),
(352, 41, '_download_expiry', '-1'),
(353, 41, '_stock', NULL),
(354, 41, '_stock_status', 'instock'),
(355, 41, '_wc_average_rating', '0'),
(356, 41, '_wc_review_count', '0'),
(357, 41, '_product_attributes', 'a:1:{s:7:"pa_vikt";a:6:{s:4:"name";s:7:"pa_vikt";s:5:"value";s:0:"";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:1;}}'),
(358, 41, '_product_version', '7.6.0'),
(359, 42, '_variation_description', 'Dumbbell av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\n\r\nTitan Life - Dumbbell 2 kg är ett effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\n\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\n\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\n\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.\r\n\r\nSpecifikationer:\r\n- Greppdiameter: 3,8 cm\r\n- Grepp: Sträv neoprenyta\r\n- Yttermaterial: Neopren\r\n- Innermaterial: Gjutjärn\r\n- Nettovikt: 2 kg\r\n\r\nÖvriga detaljer:\r\n- Skyddar golvet mot slitage\r\n- Effektivt redskap för styrke- och konditionsträning\r\n- Handtaget säkerställer ett fast grepp'),
(360, 42, 'total_sales', '0'),
(361, 42, '_tax_status', 'taxable'),
(362, 42, '_tax_class', 'parent'),
(363, 42, '_manage_stock', 'yes'),
(364, 42, '_backorders', 'no'),
(365, 42, '_sold_individually', 'no'),
(366, 42, '_virtual', 'no'),
(367, 42, '_downloadable', 'no'),
(368, 42, '_download_limit', '-1'),
(369, 42, '_download_expiry', '-1'),
(370, 42, '_stock', '7'),
(371, 42, '_stock_status', 'instock'),
(372, 42, '_wc_average_rating', '0'),
(373, 42, '_wc_review_count', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(374, 42, 'attribute_pa_vikt', '2kg'),
(375, 42, '_product_version', '7.6.0'),
(376, 43, '_variation_description', 'Dumbbell av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\n\r\nTitan Life - Dumbbell 4 kg är ett effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\n\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\n\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\n\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.\r\n\r\nSpecifikationer:\r\n- Greppdiameter: 3,8 cm\r\n- Grepp: Sträv neoprenyta\r\n- Yttermaterial: Neopren\r\n- Innermaterial: Gjutjärn\r\n- Nettovikt: 4 kg\r\n\r\nÖvriga detaljer:\r\n- Skyddar golvet mot slitage\r\n- Effektivt redskap för styrke- och konditionsträning\r\n- Handtaget säkerställer ett fast grepp'),
(377, 43, 'total_sales', '0'),
(378, 43, '_tax_status', 'taxable'),
(379, 43, '_tax_class', 'parent'),
(380, 43, '_manage_stock', 'yes'),
(381, 43, '_backorders', 'no'),
(382, 43, '_sold_individually', 'no'),
(383, 43, '_virtual', 'no'),
(384, 43, '_downloadable', 'no'),
(385, 43, '_download_limit', '-1'),
(386, 43, '_download_expiry', '-1'),
(387, 43, '_stock', '9'),
(388, 43, '_stock_status', 'instock'),
(389, 43, '_wc_average_rating', '0'),
(390, 43, '_wc_review_count', '0'),
(391, 43, 'attribute_pa_vikt', '4kg'),
(392, 43, '_product_version', '7.6.0'),
(393, 44, '_variation_description', 'Dumbbell av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\n\r\nTitan Life - Dumbbell 5 kg är ett effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\n\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\n\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\n\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.\r\n\r\nSpecifikationer:\r\n- Greppdiameter: 3,8 cm\r\n- Grepp: Sträv neoprenyta\r\n- Yttermaterial: Neopren\r\n- Innermaterial: Gjutjärn\r\n- Nettovikt: 5 kg\r\n\r\nÖvriga detaljer:\r\n- Skyddar golvet mot slitage\r\n- Effektivt redskap för styrke- och konditionsträning\r\n- Handtaget säkerställer ett fast grepp'),
(394, 44, 'total_sales', '0'),
(395, 44, '_tax_status', 'taxable'),
(396, 44, '_tax_class', 'parent'),
(397, 44, '_manage_stock', 'yes'),
(398, 44, '_backorders', 'no'),
(399, 44, '_sold_individually', 'no'),
(400, 44, '_virtual', 'no'),
(401, 44, '_downloadable', 'no'),
(402, 44, '_download_limit', '-1'),
(403, 44, '_download_expiry', '-1'),
(404, 44, '_stock', '2'),
(405, 44, '_stock_status', 'instock'),
(406, 44, '_wc_average_rating', '0'),
(407, 44, '_wc_review_count', '0'),
(408, 44, 'attribute_pa_vikt', '5kg'),
(409, 44, '_product_version', '7.6.0'),
(410, 42, '_sku', 'hantel-2kg'),
(411, 42, '_regular_price', '149'),
(412, 42, '_thumbnail_id', '14'),
(413, 42, '_price', '149'),
(414, 43, '_sku', 'hantel-4kg'),
(415, 43, '_regular_price', '249'),
(416, 43, '_thumbnail_id', '15'),
(417, 43, '_price', '249'),
(418, 44, '_sku', 'hantel-5kg'),
(419, 44, '_regular_price', '299'),
(420, 44, '_thumbnail_id', '16'),
(421, 44, '_price', '299'),
(422, 41, '_price', '149'),
(423, 41, '_price', '249'),
(424, 41, '_price', '299'),
(425, 41, '_thumbnail_id', '14'),
(426, 45, '_edit_last', '1'),
(427, 45, '_edit_lock', '1681996597:1'),
(428, 45, '_thumbnail_id', '22'),
(429, 45, '_regular_price', '29'),
(430, 45, 'total_sales', '0'),
(431, 45, '_tax_status', 'taxable'),
(432, 45, '_tax_class', ''),
(433, 45, '_manage_stock', 'no'),
(434, 45, '_backorders', 'no'),
(435, 45, '_sold_individually', 'no'),
(436, 45, '_virtual', 'no'),
(437, 45, '_downloadable', 'yes'),
(438, 45, '_download_limit', '1'),
(439, 45, '_download_expiry', '8'),
(440, 45, '_stock', NULL),
(441, 45, '_stock_status', 'instock'),
(442, 45, '_wc_average_rating', '0'),
(443, 45, '_wc_review_count', '0'),
(444, 45, '_downloadable_files', 'a:1:{s:36:"dd21f477-8a29-424d-86f1-abac4c49f7c2";a:4:{s:2:"id";s:36:"dd21f477-8a29-424d-86f1-abac4c49f7c2";s:4:"name";s:14:"traningsschema";s:4:"file";s:77:"http://localhost/labb2-linus/wp-content/uploads/2023/04/TraningsschemaPDF.pdf";s:7:"enabled";b:1;}}'),
(445, 45, '_product_version', '7.6.0'),
(446, 45, '_price', '29'),
(447, 45, '_sku', 'traningsschema'),
(448, 37, '_sale_price', '299'),
(449, 38, '_sale_price', '299'),
(450, 39, '_sale_price', '299'),
(453, 46, '_wp_attached_file', '2023/04/topp_pink.png'),
(454, 46, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:21:"2023/04/topp_pink.png";s:8:"filesize";i:1066444;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:21:"topp_pink-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:70069;}s:5:"large";a:5:{s:4:"file";s:23:"topp_pink-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:633841;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"topp_pink-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21023;}s:12:"medium_large";a:5:{s:4:"file";s:21:"topp_pink-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:492881;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:21:"topp_pink-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:96170;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:21:"topp_pink-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153891;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:21:"topp_pink-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9900;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(455, 47, '_wp_attached_file', '2023/04/topp_black.png'),
(456, 47, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/topp_black.png";s:8:"filesize";i:662076;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"topp_black-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:59624;}s:5:"large";a:5:{s:4:"file";s:24:"topp_black-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:433619;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"topp_black-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18570;}s:12:"medium_large";a:5:{s:4:"file";s:22:"topp_black-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:385957;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"topp_black-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:82337;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"topp_black-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:127913;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"topp_black-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8789;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(457, 34, '_thumbnail_id', '46'),
(458, 35, '_thumbnail_id', '46'),
(459, 36, '_thumbnail_id', '46'),
(460, 37, '_thumbnail_id', '47'),
(461, 38, '_thumbnail_id', '47'),
(462, 39, '_thumbnail_id', '47'),
(463, 33, '_price', '299'),
(464, 33, '_price', '399'),
(465, 33, '_thumbnail_id', '46'),
(466, 48, '_wp_attached_file', '2023/04/yogatights.png'),
(467, 48, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:1400;s:4:"file";s:22:"2023/04/yogatights.png";s:8:"filesize";i:740020;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:22:"yogatights-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45806;}s:5:"large";a:5:{s:4:"file";s:24:"yogatights-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:346792;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"yogatights-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14876;}s:12:"medium_large";a:5:{s:4:"file";s:22:"yogatights-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:348930;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:22:"yogatights-324x324.png";s:5:"width";i:324;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71178;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:22:"yogatights-416x416.png";s:5:"width";i:416;s:6:"height";i:416;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:109729;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:22:"yogatights-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7032;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(468, 25, '_thumbnail_id', '48'),
(469, 49, '_menu_item_type', 'taxonomy'),
(470, 49, '_menu_item_menu_item_parent', '0'),
(471, 49, '_menu_item_object_id', '24'),
(472, 49, '_menu_item_object', 'product_cat'),
(473, 49, '_menu_item_target', ''),
(474, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(475, 49, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(476, 49, '_menu_item_url', ''),
(478, 50, '_menu_item_type', 'taxonomy'),
(479, 50, '_menu_item_menu_item_parent', '0'),
(480, 50, '_menu_item_object_id', '32'),
(481, 50, '_menu_item_object', 'product_cat'),
(482, 50, '_menu_item_target', ''),
(483, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(484, 50, '_menu_item_xfn', ''),
(485, 50, '_menu_item_url', ''),
(487, 51, '_menu_item_type', 'taxonomy'),
(488, 51, '_menu_item_menu_item_parent', '0'),
(489, 51, '_menu_item_object_id', '25'),
(490, 51, '_menu_item_object', 'product_cat'),
(491, 51, '_menu_item_target', ''),
(492, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(493, 51, '_menu_item_xfn', ''),
(494, 51, '_menu_item_url', ''),
(495, 52, '_edit_last', '1'),
(496, 52, '_edit_lock', '1682321539:1'),
(497, 52, 'discount_type', 'fixed_cart'),
(498, 52, 'coupon_amount', '100'),
(499, 52, 'individual_use', 'yes'),
(500, 52, 'usage_limit', '1'),
(501, 52, 'usage_limit_per_user', '1'),
(502, 52, 'limit_usage_to_x_items', '0'),
(503, 52, 'usage_count', '0'),
(504, 52, 'date_expires', '1688076000'),
(505, 52, 'free_shipping', 'yes'),
(506, 52, 'exclude_sale_items', 'no'),
(507, 52, 'minimum_amount', '100'),
(508, 52, 'maximum_amount', '2000'),
(509, 2, '_wp_trash_meta_status', 'publish'),
(510, 2, '_wp_trash_meta_time', '1682346056'),
(511, 2, '_wp_desired_post_slug', 'exempelsida'),
(512, 6, '_edit_lock', '1682345933:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-04-19 15:03:25', '2023-04-19 13:03:25', '<!-- wp:paragraph -->\n<p>Välkommen till WordPress. Detta är ditt första inlägg. Du kan redigera det eller ta bort det. Sedan är det bara att börja skriva!</p>\n<!-- /wp:paragraph -->', 'Hej världen!', '', 'publish', 'open', 'open', '', 'hej-varlden', '', '', '2023-04-19 15:03:25', '2023-04-19 13:03:25', '', 0, 'http://localhost/labb2-linus/?p=1', 0, 'post', '', 1),
(2, 1, '2023-04-19 15:03:25', '2023-04-19 13:03:25', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/labb2-linus/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'trash', 'closed', 'open', '', 'exempelsida__trashed', '', '', '2023-04-24 16:20:56', '2023-04-24 14:20:56', '', 0, 'http://localhost/labb2-linus/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-04-19 15:03:25', '2023-04-19 13:03:25', '<!-- wp:heading --><h2>Vilka vi är</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Vår webbplatsadress är: http://localhost/labb2-linus.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Kommentarer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>När besökare lämnar kommentarer på webbplatsen samlar vi in de uppgifter som visas i kommentarsformuläret samt besökarens IP-adress och webbläsarens användaragent-sträng som hjälp för detektering av skräppost.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>En anonymiserad sträng som skapats utifrån din e-postadress (även kallat hash-värde) kan komma att sändas till tjänsten Gravatar för att avgöra om du finns registrerad där. Integritetspolicyn för tjänsten Gravatar finns på https://automattic.com/privacy/. När din kommentar har godkänts visas din profilbild offentligt tillsammans med din kommentar.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du laddar upp bilder till webbplatsen bör du undvika att ladda upp bilder där EXIF-data inkluderar data från GPS-lokalisering. Besökare till webbplatsen kan ladda ned och ta fram alla positioneringsuppgifter från bilder på webbplatsen.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie-filer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du lämnar en kommentar på vår webbplats kan du välja att spara ditt namn, din e-postadress och webbplatsadress i cookie-filer. Detta är för din bekvämlighet för att du inte ska behöva fylla i dessa uppgifter igen nästa gång du skriver en kommentar. Dessa cookie-filer gäller i ett år.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du besöker vår inloggningssida kommer vi att sätta en tillfällig cookie för att undersöka om din webbläsare accepterar dem. Denna cookie innehåller inga personuppgifter och den försvinner när du stänger din webbläsare.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>När du loggar in kommer vi dessutom att skapa flera cookie-filer för att spara information om din inloggning och dina val för utformning av skärmlayouten. Cookie-filer för inloggning gäller i två dagar och cookie-filer för layoutval gäller i ett år. Om du kryssar i ”Kom ihåg mig” kommer din cookie att finnas kvar i två veckor. Om du loggar ut från ditt konto kommer cookie-filerna för inloggning att tas bort.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du redigerar eller publicerar en artikel kommer en extra cookie-fil att sparas i din webbläsare. Denna cookie-fil innehåller inga personuppgifter utan anger endast inläggs-ID för den artikel du just redigerade och löper ut efter ett dygn.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Inbäddad innehåll från andra webbplatser</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Artiklar på denna webbplats kan innehålla inbäddat innehåll (exempelvis videoklipp, bilder, artiklar o.s.v.). Inbäddat innehåll från andra webbplatser beter sig precis på samma sätt som om besökaren har besökt den andra webbplatsen.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Dessa webbplatser kan samla in uppgifter om dig, använda cookie-filer, bädda in ytterligare spårning från tredje part och övervaka din interaktion med sagda inbäddade innehåll, inklusive spårning av din interaktion med detta inbäddade innehåll om du har ett konto och är inloggad på webbplatsen i fråga.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka vi delar dina data med</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du begär återställning av lösenordet kommer din IP-adress att ingå i e-postmeddelandet om återställning.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Hur länge vi behåller era uppgifter</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du skriver en kommentar kommer kommentaren och dess metadata att sparas utan tidsgräns. Anledningen till detta är att vi behöver kunna hitta och godkänna uppföljningskommentarer automatiskt och inte lägga dem i kö för granskning.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>För användare som registrerar sig på er webbplats (om sådana finns) sparar vi även de personuppgifter de anger i sin användarprofil. Alla användare kan se, redigera eller radera sina personuppgifter när som helst (med undantaget att de inte kan ändra sitt användarnamn). Även webbplatsens administratörer kan se och redigera denna information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka rättigheter du har över dina data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du har ett konto eller har skrivit några kommentarer på denna webbplats kan du begära en exportfil med de personuppgifter vi har om dig, inklusive alla uppgifter du har gett oss. Du kan också begära att vi tar bort alla personuppgifter vi har om dig. Detta omfattar inte eventuella uppgifter som vi är tvungna att spara av administrativa, legala eller säkerhetsändamål.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vart dina uppgifter skickas</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Kommentarer från besökare kanske kontrolleras via en automatiserad tjänst för detektering av skräppost.</p><!-- /wp:paragraph -->', 'Integritetspolicy', '', 'draft', 'closed', 'open', '', 'integritetspolicy', '', '', '2023-04-19 15:03:25', '2023-04-19 13:03:25', '', 0, 'http://localhost/labb2-linus/?page_id=3', 0, 'page', '', 0),
(4, 1, '2023-04-19 15:03:33', '0000-00-00 00:00:00', '', 'Automatiskt utkast', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-04-19 15:03:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/labb2-linus/?p=4', 0, 'post', '', 0),
(5, 1, '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 0, 'http://localhost/labb2-linus/shop/', 0, 'page', '', 0),
(7, 1, '2023-04-19 15:20:10', '2023-04-19 13:20:10', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 0, 'http://localhost/labb2-linus/cart/', 0, 'page', '', 0),
(8, 1, '2023-04-19 15:20:10', '2023-04-19 13:20:10', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 0, 'http://localhost/labb2-linus/checkout/', 0, 'page', '', 0),
(9, 1, '2023-04-19 15:20:10', '2023-04-19 13:20:10', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2023-04-19 15:20:10', '2023-04-19 13:20:10', '', 0, 'http://localhost/labb2-linus/my-account/', 0, 'page', '', 0),
(10, 1, '2023-04-19 15:20:10', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'draft', 'closed', 'closed', '', 'refund_returns', '', '', '2023-04-19 15:20:10', '0000-00-00 00:00:00', '', 0, 'http://localhost/labb2-linus/?page_id=10', 0, 'page', '', 0),
(11, 1, '2023-04-19 15:31:16', '2023-04-19 13:31:16', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 15:31:16', '2023-04-19 13:31:16', '', 0, 'http://localhost/labb2-linus/?post_type=product&p=11', 0, 'product', '', 0),
(14, 1, '2023-04-19 15:32:43', '2023-04-19 13:32:43', '', 'handel_2kg', '', 'inherit', 'open', 'closed', '', 'handel_2kg', '', '', '2023-04-19 15:32:43', '2023-04-19 13:32:43', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/handel_2kg.png', 0, 'attachment', 'image/png', 0),
(15, 1, '2023-04-19 15:32:44', '2023-04-19 13:32:44', '', 'hantel_4kg', '', 'inherit', 'open', 'closed', '', 'hantel_4kg', '', '', '2023-04-19 15:32:44', '2023-04-19 13:32:44', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/hantel_4kg.png', 0, 'attachment', 'image/png', 0),
(16, 1, '2023-04-19 15:32:45', '2023-04-19 13:32:45', '', 'hantel_5kg', '', 'inherit', 'open', 'closed', '', 'hantel_5kg', '', '', '2023-04-19 15:32:45', '2023-04-19 13:32:45', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/hantel_5kg.png', 0, 'attachment', 'image/png', 0),
(20, 1, '2023-04-19 15:32:48', '2023-04-19 13:32:48', '', 'yogamatta', 'yogamatta', 'inherit', 'open', 'closed', '', 'yogamatta', '', '', '2023-04-20 12:52:50', '2023-04-20 10:52:50', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/yogamatta.png', 0, 'attachment', 'image/png', 0),
(21, 1, '2023-04-19 15:32:50', '2023-04-19 13:32:50', '', 'yogamatta_pink', '', 'inherit', 'open', 'closed', '', 'yogamatta_pink', '', '', '2023-04-19 15:32:50', '2023-04-19 13:32:50', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/yogamatta_pink.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2023-04-19 15:33:23', '2023-04-19 13:33:23', '', 'Traningsschema', '', 'inherit', 'open', 'closed', '', 'traningsschema', '', '', '2023-04-19 15:33:23', '2023-04-19 13:33:23', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/Traningsschema.png', 0, 'attachment', 'image/png', 0),
(23, 1, '2023-04-19 15:33:26', '2023-04-19 13:33:26', '', 'TräningsschemaPDF', '', 'inherit', 'open', 'closed', '', 'traningsschemapdf', '', '', '2023-04-19 15:33:26', '2023-04-19 13:33:26', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/TraningsschemaPDF.pdf', 0, 'attachment', 'application/pdf', 0),
(24, 1, '2023-04-19 15:36:36', '2023-04-19 13:36:36', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-19 15:36:36', '2023-04-19 13:36:36', '', 0, 'http://localhost/labb2-linus/?post_type=product&p=24', 0, 'product', '', 0),
(25, 1, '2023-04-19 15:56:19', '2023-04-19 13:56:19', 'Tights som passar perfekt till yoga, pilates och stretching.\r\n\r\nSpecifikationer:\r\n- Passform: Åtsittande\r\n- Material: 67 % återvunnen polyester, 28 % återvunnen polyamid, 5 % elastan\r\n- Andas: Ja\r\n- Leder bort fukt: Ja\r\n\r\nÖvriga detaljer:\r\n- Bred resår i midjan\r\n- Liten logo på vänster höft', 'Yogatights', 'Tights som passar perfekt till yoga, pilates och stretching.', 'publish', 'open', 'closed', '', 'yogatights', '', '', '2023-04-20 15:59:09', '2023-04-20 13:59:09', '', 0, 'http://localhost/labb2-linus/?post_type=product&#038;p=25', 0, 'product', '', 0),
(29, 1, '2023-04-20 11:40:16', '2023-04-20 09:40:16', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-20 11:40:16', '2023-04-20 09:40:16', '', 0, 'http://localhost/labb2-linus/?post_type=product&p=29', 0, 'product', '', 0),
(30, 1, '2023-04-20 11:58:28', '2023-04-20 09:58:28', '', 'Yogatights - Large', 'Storlek: Large', 'publish', 'closed', 'closed', '', 'yogatights-large', '', '', '2023-04-20 12:01:42', '2023-04-20 10:01:42', '', 25, 'http://localhost/labb2-linus/?post_type=product_variation&p=30', 1, 'product_variation', '', 0),
(31, 1, '2023-04-20 11:58:28', '2023-04-20 09:58:28', '', 'Yogatights - Medium', 'Storlek: Medium', 'publish', 'closed', 'closed', '', 'yogatights-medium', '', '', '2023-04-20 12:01:42', '2023-04-20 10:01:42', '', 25, 'http://localhost/labb2-linus/?post_type=product_variation&p=31', 2, 'product_variation', '', 0),
(32, 1, '2023-04-20 11:58:28', '2023-04-20 09:58:28', '', 'Yogatights - Small', 'Storlek: Small', 'publish', 'closed', 'closed', '', 'yogatights-small', '', '', '2023-04-20 12:01:43', '2023-04-20 10:01:43', '', 25, 'http://localhost/labb2-linus/?post_type=product_variation&p=32', 3, 'product_variation', '', 0),
(33, 1, '2023-04-20 12:04:19', '2023-04-20 10:04:19', 'Teknisk träningströja i fukttransporterande och snabbtorkande material. Half Zip fram, Puma-logga och tumhål.\r\nPuma Runtrain 1/4 är ett utmärkt val för all slags av träning.\r\n\r\ndryCELL-tekniken håller dig torr och sval under aktivitet.\r\n\r\nHalv dragkedja framtill möjliggör ventilation.\r\n\r\nTumhålen vid muffen hindrar ärmarna från att glida upp.\r\n\r\nSpecifikationer:\r\n- Passform: Åtsittande\r\n- Material: 100 % återvunnen polyester\r\n- Material som andas: Ja\r\n- Fukttransporterande: Ja\r\n\r\nÖvriga detaljer:\r\n- Halv-Zip fram\r\n- Puma-logga vid vänster bröst\r\n- Hål för tummen', 'Träningstopp', 'Teknisk träningströja i fukttransporterande och snabbtorkande material. Half Zip fram, Puma-logga och tumhål.\r\nPuma Runtrain 1/4 är ett utmärkt val för all slags av träning.\r\n\r\ndryCELL-tekniken håller dig torr och sval under aktivitet.\r\n\r\nHalv dragkedja framtill möjliggör ventilation.\r\n\r\nTumhålen vid muffen hindrar ärmarna från att glida upp.', 'publish', 'open', 'closed', '', 'traningstopp', '', '', '2023-04-20 15:57:54', '2023-04-20 13:57:54', '', 0, 'http://localhost/labb2-linus/?post_type=product&#038;p=33', 0, 'product', '', 0),
(34, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Rosa, Large', 'Färg: Rosa, Storlek: Large', 'publish', 'closed', 'closed', '', 'traningstopp-large-rosa', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=34', 1, 'product_variation', '', 0),
(35, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Rosa, Medium', 'Färg: Rosa, Storlek: Medium', 'publish', 'closed', 'closed', '', 'traningstopp-medium-rosa', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=35', 2, 'product_variation', '', 0),
(36, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Rosa, Small', 'Färg: Rosa, Storlek: Small', 'publish', 'closed', 'closed', '', 'traningstopp-small-rosa', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=36', 3, 'product_variation', '', 0),
(37, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Svart, Large', 'Färg: Svart, Storlek: Large', 'publish', 'closed', 'closed', '', 'traningstopp-large-svart', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=37', 4, 'product_variation', '', 0),
(38, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Svart, Medium', 'Färg: Svart, Storlek: Medium', 'publish', 'closed', 'closed', '', 'traningstopp-medium-svart', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=38', 5, 'product_variation', '', 0),
(39, 1, '2023-04-20 12:11:11', '2023-04-20 10:11:11', '', 'Träningstopp - Svart, Small', 'Färg: Svart, Storlek: Small', 'publish', 'closed', 'closed', '', 'traningstopp-small-svart', '', '', '2023-04-20 15:57:07', '2023-04-20 13:57:07', '', 33, 'http://localhost/labb2-linus/?post_type=product_variation&p=39', 6, 'product_variation', '', 0),
(40, 1, '2023-04-20 12:52:33', '2023-04-20 10:52:33', 'Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar. 5 mm tjock.\r\n\r\nSpecifikationer:\r\n- Tjocklek: 5 mm', 'Yogamatta', 'Träningsmatta som säkerställer bra grepp och bra dämpning mot golvet och ger en bra grund för grundläggande flexibilitet och styrkeövningar. 5 mm tjock.', 'publish', 'open', 'closed', '', 'yogamatta', '', '', '2023-04-20 12:54:33', '2023-04-20 10:54:33', '', 0, 'http://localhost/labb2-linus/?post_type=product&#038;p=40', 0, 'product', '', 0),
(41, 1, '2023-04-20 12:54:42', '2023-04-20 10:54:42', 'Dumbbell av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\n\r\nDumbbell är ett effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\n\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\n\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\n\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.\r\n\r\nSpecifikationer:\r\n- Greppdiameter: 3,8 cm\r\n- Grepp: Sträv neoprenyta\r\n- Yttermaterial: Neopren\r\n- Innermaterial: Gjutjärn\r\n\r\nÖvriga detaljer:\r\n- Skyddar golvet mot slitage\r\n- Effektivt redskap för styrke- och konditionsträning\r\n- Handtaget säkerställer ett fast grepp', 'Hantel', 'Dumbbell av gjutjärn med en flexibel gummiyta. Effektivt redskap för styrke- och konditionsträning. Gummiytan skyddar golvet mot nötning.\r\n\r\nDumbbell är ett effektivt redskap för styrke- och konditionsträning. Tillverkade i gjutjärn med en flexibel gummiyta som skyddar golvet.\r\n\r\nNeopren-handtaget säkerställer ett fast grepp, även med svettiga handflator.\r\n\r\nStyrketräning är en av de mest effektiva metoderna för att minska kroppsfett, öka muskelmassan och bränna kalorier.\r\n\r\nAnvänd hantlarna för isolerade såväl som sammansatta rörelser, som extra vikt under knäböj eller armhävningar för extra motstånd.', 'publish', 'open', 'closed', '', 'hantel', '', '', '2023-04-21 09:56:25', '2023-04-21 07:56:25', '', 0, 'http://localhost/labb2-linus/?post_type=product&#038;p=41', 0, 'product', '', 0),
(42, 1, '2023-04-20 12:55:54', '2023-04-20 10:55:54', '', 'Hantel - 2kg', 'Vikt: 2kg', 'publish', 'closed', 'closed', '', 'hantel-2kg', '', '', '2023-04-20 12:59:24', '2023-04-20 10:59:24', '', 41, 'http://localhost/labb2-linus/?post_type=product_variation&p=42', 1, 'product_variation', '', 0),
(43, 1, '2023-04-20 12:55:54', '2023-04-20 10:55:54', '', 'Hantel - 4kg', 'Vikt: 4kg', 'publish', 'closed', 'closed', '', 'hantel-4kg', '', '', '2023-04-20 12:59:24', '2023-04-20 10:59:24', '', 41, 'http://localhost/labb2-linus/?post_type=product_variation&p=43', 2, 'product_variation', '', 0),
(44, 1, '2023-04-20 12:55:54', '2023-04-20 10:55:54', '', 'Hantel - 5kg', 'Vikt: 5kg', 'publish', 'closed', 'closed', '', 'hantel-5kg', '', '', '2023-04-20 12:59:24', '2023-04-20 10:59:24', '', 41, 'http://localhost/labb2-linus/?post_type=product_variation&p=44', 3, 'product_variation', '', 0),
(45, 1, '2023-04-20 15:15:57', '2023-04-20 13:15:57', '', 'Träningsschema', '', 'publish', 'open', 'closed', '', 'traningsschema', '', '', '2023-04-20 15:18:51', '2023-04-20 13:18:51', '', 0, 'http://localhost/labb2-linus/?post_type=product&#038;p=45', 0, 'product', '', 0),
(46, 1, '2023-04-20 15:56:11', '2023-04-20 13:56:11', '', 'topp_pink', '', 'inherit', 'open', 'closed', '', 'topp_pink', '', '', '2023-04-20 15:56:11', '2023-04-20 13:56:11', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/topp_pink.png', 0, 'attachment', 'image/png', 0),
(47, 1, '2023-04-20 15:56:12', '2023-04-20 13:56:12', '', 'topp_black', '', 'inherit', 'open', 'closed', '', 'topp_black', '', '', '2023-04-20 15:56:12', '2023-04-20 13:56:12', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/topp_black.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2023-04-20 15:58:47', '2023-04-20 13:58:47', '', 'yogatights', '', 'inherit', 'open', 'closed', '', 'yogatights-2', '', '', '2023-04-20 15:58:47', '2023-04-20 13:58:47', '', 0, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/yogatights.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2023-04-21 09:55:34', '2023-04-21 07:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2023-04-21 09:55:34', '2023-04-21 07:55:34', '', 0, 'http://localhost/labb2-linus/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2023-04-21 09:55:34', '2023-04-21 07:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2023-04-21 09:55:34', '2023-04-21 07:55:34', '', 0, 'http://localhost/labb2-linus/?p=50', 2, 'nav_menu_item', '', 0),
(51, 1, '2023-04-21 09:55:34', '2023-04-21 07:55:34', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2023-04-21 09:55:34', '2023-04-21 07:55:34', '', 0, 'http://localhost/labb2-linus/?p=51', 3, 'nav_menu_item', '', 0),
(52, 1, '2023-04-24 09:32:46', '2023-04-24 07:32:46', '', 'hejsan123', '', 'publish', 'closed', 'closed', '', 'hejsan123', '', '', '2023-04-24 09:34:19', '2023-04-24 07:34:19', '', 0, 'http://localhost/labb2-linus/?post_type=shop_coupon&#038;p=52', 0, 'shop_coupon', '', 0),
(53, 1, '2023-04-24 16:20:56', '2023-04-24 14:20:56', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/labb2-linus/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-04-24 16:20:56', '2023-04-24 14:20:56', '', 2, 'http://localhost/labb2-linus/?p=53', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(25, 4, 0),
(25, 18, 0),
(25, 19, 0),
(25, 20, 0),
(25, 24, 0),
(25, 27, 0),
(33, 4, 0),
(33, 16, 0),
(33, 17, 0),
(33, 18, 0),
(33, 19, 0),
(33, 20, 0),
(33, 24, 0),
(33, 26, 0),
(40, 2, 0),
(40, 25, 0),
(40, 28, 0),
(41, 4, 0),
(41, 21, 0),
(41, 22, 0),
(41, 23, 0),
(41, 25, 0),
(41, 29, 0),
(45, 2, 0),
(45, 30, 0),
(45, 32, 0),
(49, 33, 0),
(50, 33, 0),
(51, 33, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 2),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 3),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'pa_farg', '', 0, 1),
(17, 17, 'pa_farg', '', 0, 1),
(18, 18, 'pa_storlek', '', 0, 2),
(19, 19, 'pa_storlek', '', 0, 2),
(20, 20, 'pa_storlek', '', 0, 2),
(21, 21, 'pa_vikt', '', 0, 1),
(22, 22, 'pa_vikt', '', 0, 1),
(23, 23, 'pa_vikt', '', 0, 1),
(24, 24, 'product_cat', '', 0, 2),
(25, 25, 'product_cat', '', 0, 2),
(26, 26, 'product_cat', '', 24, 1),
(27, 27, 'product_cat', '', 24, 1),
(28, 28, 'product_cat', '', 25, 1),
(29, 29, 'product_cat', '', 25, 1),
(30, 30, 'product_shipping_class', 'No shipping on digital products', 0, 1),
(31, 31, 'product_shipping_class', 'Fragile products, more expensive shipping', 0, 0),
(32, 32, 'product_cat', '', 0, 1),
(33, 33, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 16, 'order', '0'),
(2, 17, 'order', '0'),
(3, 18, 'order', '0'),
(4, 19, 'order', '0'),
(5, 20, 'order', '0'),
(6, 21, 'order', '0'),
(7, 22, 'order', '0'),
(8, 23, 'order', '0'),
(9, 15, 'product_count_product_cat', '0'),
(10, 24, 'order', '0'),
(11, 24, 'display_type', ''),
(12, 24, 'thumbnail_id', '0'),
(13, 25, 'order', '0'),
(14, 25, 'display_type', ''),
(15, 25, 'thumbnail_id', '0'),
(16, 26, 'order', '0'),
(17, 26, 'display_type', ''),
(18, 26, 'thumbnail_id', '0'),
(19, 27, 'order', '0'),
(20, 27, 'display_type', ''),
(21, 27, 'thumbnail_id', '0'),
(22, 24, 'product_count_product_cat', '2'),
(23, 27, 'product_count_product_cat', '1'),
(24, 28, 'order', '0'),
(25, 28, 'display_type', ''),
(26, 28, 'thumbnail_id', '0'),
(27, 29, 'order', '0'),
(28, 29, 'display_type', ''),
(29, 29, 'thumbnail_id', '0'),
(30, 26, 'product_count_product_cat', '1'),
(31, 25, 'product_count_product_cat', '2'),
(32, 28, 'product_count_product_cat', '1'),
(33, 32, 'order', '0'),
(34, 32, 'display_type', ''),
(35, 32, 'thumbnail_id', '0'),
(36, 32, 'product_count_product_cat', '1'),
(37, 29, 'product_count_product_cat', '1') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Okategoriserade', 'okategoriserade', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Rosa', 'rosa', 0),
(17, 'Svart', 'svart', 0),
(18, 'Small', 'small', 0),
(19, 'Medium', 'medium', 0),
(20, 'Large', 'large', 0),
(21, '2kg', '2kg', 0),
(22, '4kg', '4kg', 0),
(23, '5kg', '5kg', 0),
(24, 'Kläder', 'klader', 0),
(25, 'Utrustning', 'utrustning', 0),
(26, 'Överdel', 'overdel', 0),
(27, 'Underdel', 'underdel', 0),
(28, 'Yoga', 'yoga', 0),
(29, 'Gym', 'gym', 0),
(30, 'Digital product', 'digital-product', 0),
(31, 'Fragile', 'fragile', 0),
(32, 'Träningsschema', 'traningsschema', 0),
(33, 'Undermeny', 'undermeny', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'linus'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', 'sv_SE'),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"c9ce3cecae7ded45225ad7f6e5c34ec30924d2ef2101e5ccd02622e61016a3a6";a:4:{s:10:"expiration";i:1682494356;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1682321556;}}'),
(17, 1, 'wp_user-settings', 'libraryContent=browse'),
(18, 1, 'wp_user-settings-time', '1681909408'),
(19, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(20, 1, 'wc_last_active', '1682294400'),
(21, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:56:"woocommerce-product-data,,postexcerpt,postcustom,slugdiv";s:8:"advanced";s:0:"";}'),
(23, 1, '_woocommerce_tracks_anon_id', 'woo:ecrkkFx9pUuJd03GGwTdb11z'),
(24, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:0:{}}'),
(25, 1, 'screen_layout_product', '2'),
(26, 1, 'billing_first_name', ''),
(27, 1, 'billing_last_name', ''),
(28, 1, 'billing_company', ''),
(29, 1, 'billing_address_1', ''),
(30, 1, 'billing_address_2', ''),
(31, 1, 'billing_city', ''),
(32, 1, 'billing_postcode', ''),
(33, 1, 'billing_country', ''),
(34, 1, 'billing_state', ''),
(35, 1, 'billing_phone', ''),
(36, 1, 'billing_email', 'lundell.linus@gmail.com'),
(37, 1, 'shipping_first_name', ''),
(38, 1, 'shipping_last_name', ''),
(39, 1, 'shipping_company', ''),
(40, 1, 'shipping_address_1', ''),
(41, 1, 'shipping_address_2', ''),
(42, 1, 'shipping_city', ''),
(43, 1, 'shipping_postcode', ''),
(44, 1, 'shipping_country', ''),
(45, 1, 'shipping_state', ''),
(46, 1, 'shipping_phone', ''),
(47, 1, 'last_update', '1681993944'),
(49, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(50, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:21:"add-post-type-product";i:1;s:12:"add-post_tag";i:2;s:15:"add-product_tag";}'),
(51, 1, 'nav_menu_recently_edited', '33'),
(52, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(54, 1, 'manageedit-shop_ordercolumnshidden', 'a:1:{i:0;s:16:"shipping_address";}'),
(55, 1, 'edit_shop_order_per_page', '20') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'linus', '$P$BUjYWUbjXb/xyVoHxg0KPM1wXJVzqS/', 'linus', 'lundell.linus@gmail.com', 'http://localhost/labb2-linus', '2023-04-19 13:03:25', '', 0, 'linus') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=481 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(60, 50, 'notify-refund-returns-page', 'Edit page', 'http://localhost/labb2-linus/wp-admin/post.php?post=10&action=edit', 'actioned', '', NULL, NULL),
(120, 51, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(180, 52, 'customize-store-with-storefront', 'Let\'s go!', 'http://localhost/labb2-linus/wp-admin/themes.php?page=storefront-welcome', 'actioned', '', NULL, NULL),
(181, 53, 'visit-the-theme-marketplace', 'Besök temamarknadsplatsen', 'https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(182, 54, 'learn-more', 'Lär dig mer', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(301, 55, 'day-after-first-product', 'Lär dig mer', 'https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(302, 56, 'learn-more', 'Lär dig mer', 'https://woocommerce.com/mobile/?utm_medium=product', 'actioned', '', NULL, NULL),
(303, 57, 'online-clothing-store', 'Lär dig mer', 'https://woocommerce.com/posts/starting-an-online-clothing-store/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(422, 1, 'browse_extensions', 'Browse extensions', 'http://localhost/labb2-linus/wp-admin/admin.php?page=wc-addons', 'unactioned', '', NULL, NULL),
(423, 2, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(424, 3, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(425, 4, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(426, 5, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(427, 6, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(428, 7, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(429, 8, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(430, 9, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(431, 10, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost/labb2-linus/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(432, 11, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(433, 14, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(434, 15, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(435, 16, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(436, 16, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(437, 17, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(438, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(439, 18, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(440, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(441, 19, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(442, 19, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(443, 20, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(444, 21, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(445, 21, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(446, 22, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(447, 22, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(448, 23, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(449, 24, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(450, 25, 'wc-admin-wisepad3', 'Grow my business offline', 'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3', 'actioned', '', NULL, NULL),
(451, 26, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(452, 26, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(453, 27, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(454, 27, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(455, 28, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'Learn more', 'https://woocommerce.com/document/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_custom_attribute_mapping_q4_2022#attribute-mapping', 'actioned', '', NULL, NULL),
(456, 29, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'http://localhost/labb2-linus/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(457, 29, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(458, 30, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'http://localhost/labb2-linus/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(459, 30, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(460, 31, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(461, 32, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'Boost my business with Google', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_no_gla', 'actioned', '', NULL, NULL),
(462, 33, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'Create a new ad', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_with_gla', 'actioned', '', NULL, NULL),
(463, 34, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(464, 34, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(465, 35, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(466, 36, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'Set up Tap to Pay on iPhone', 'https://woocommerce.com/document/woocommerce-payments/in-person-payments/woocommerce-in-person-payments-tap-to-pay-on-iphone-quick-start-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_with_wcpay', 'actioned', '', NULL, NULL),
(467, 37, 'extension-settings', 'See available updates', 'http://localhost/labb2-linus/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(468, 37, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(469, 38, 'wc-admin-wcpay-denmark-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/denmark/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-denmark-Q2-2023', 'actioned', '', NULL, NULL),
(470, 39, 'wc-admin-wcpay-greece-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/greece/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-greece-Q2-2023', 'actioned', '', NULL, NULL),
(471, 40, 'wc-admin-wcpay-norway-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/norway/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-norway-Q2-2023', 'actioned', '', NULL, NULL),
(472, 41, 'wc-admin-wcpay-slovakia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovakia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovakia-Q2-2023', 'actioned', '', NULL, NULL),
(473, 42, 'wc-admin-wcpay-finland-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/finland/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-finland-Q2-2023', 'actioned', '', NULL, NULL),
(474, 43, 'wc-admin-wcpay-estonia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/estonia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-estonia-Q2-2023', 'actioned', '', NULL, NULL),
(475, 44, 'wc-admin-wcpay-lithuania-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/lithuania/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-lithuania-Q2-2023', 'actioned', '', NULL, NULL),
(476, 45, 'wc-admin-wcpay-slovenia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovenia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovenia-Q2-2023', 'actioned', '', NULL, NULL),
(477, 46, 'wc-admin-wcpay-latvia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/latvia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-latvia-Q2-2023', 'actioned', '', NULL, NULL),
(478, 47, 'wc-admin-wcpay-cyprus-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/cyprus/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-cyprus-Q2-2023', 'actioned', '', NULL, NULL),
(479, 48, 'wc-admin-wcpay-malta-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/malta/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-malta-Q2-2023', 'actioned', '', NULL, NULL),
(480, 49, 'wc-admin-wcpay-luxembourg-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/luxembourg/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-luxembourg-Q2-2023', 'actioned', '', NULL, NULL) ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'new_in_app_marketplace_2021', 'info', 'en_US', 'Customize your store with extensions', 'Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 1, 'info'),
(2, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woocommerce.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 13:21:24', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'unactioned', 'woocommerce.com', '2023-04-24 07:32:31', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woocommerce.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woocommerce.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(23, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'wc-admin-wisepad3', 'marketing', 'en_US', 'Take your business on the go in Canada with WooCommerce In-Person Payments', 'Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'woocommerce-payments-august-2022-need-to-update', 'update', 'en_US', 'Action required: Please update WooCommerce Payments', 'An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woocommerce-payments-august-2022-store-patched', 'update', 'en_US', 'WooCommerce Payments has been automatically updated', 'You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'marketing', 'en_US', 'Our latest improvement to the Google Listings & Ads extension: Attribute Mapping', 'You spoke, we listened. This new feature enables you to easily upload your products, customize your product attributes in one place, and target shoppers with more relevant ads. Extend how far your ad dollars go with each campaign.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'marketing', 'en_US', 'Create more engaging ads – without the hard work', 'Get in front of millions of shoppers searching for products like yours with Google Listings &amp; Ads. With new customization features, Google automatically tests multiple combinations of text and images to create the most engaging ad to boost your business. Plus, get up to $500 in ad credit – terms and conditions apply.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 1, 'info'),
(33, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'marketing', 'en_US', 'New customization features to boost your business', 'You can now add custom images, messaging, and URLs to campaigns in Google Listings &amp; Ads. Google then automatically tests multiple combinations to create the most engaging version to help boost your business. Get more sales with dynamic content – edit an existing campaign or create a new ad now.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(34, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'unactioned', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 1, 'info'),
(36, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'marketing', 'en_US', 'New: accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone is quick, secure, and simple to set up in WooCommerce Payments — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person in a few short steps!', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(37, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'wc-admin-wcpay-denmark-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Denmark!', 'We’ve recently released WooCommerce Payments in Denmark. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'wc-admin-wcpay-greece-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Greece!', 'We’ve recently released WooCommerce Payments in Greece. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'wc-admin-wcpay-norway-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Norway!', 'We’ve recently released WooCommerce Payments in Norway. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'wc-admin-wcpay-slovakia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovakia!', 'We’ve recently released WooCommerce Payments in Slovakia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'wc-admin-wcpay-finland-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Finland!', 'We’ve recently released WooCommerce Payments in Finland. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'wc-admin-wcpay-estonia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Estonia!', 'We’ve recently released WooCommerce Payments in Estonia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'wc-admin-wcpay-lithuania-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Lithuania!', 'We’ve recently released WooCommerce Payments in Lithuania. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'wc-admin-wcpay-slovenia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovenia!', 'We’ve recently released WooCommerce Payments in Slovenia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'wc-admin-wcpay-latvia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Latvia!', 'We’ve recently released WooCommerce Payments in Latvia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'wc-admin-wcpay-cyprus-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Cyprus!', 'We’ve recently released WooCommerce Payments in Cyprus. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'wc-admin-wcpay-malta-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Malta!', 'We’ve recently released WooCommerce Payments in Malta. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'wc-admin-wcpay-luxembourg-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Luxembourg!', 'We’ve recently released WooCommerce Payments in Luxembourg. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2023-04-19 13:20:12', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to WooCommerce.com', 'Connect to get important product notifications and updates.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-19 13:20:13', NULL, 0, 'plain', '', 0, 1, 'info'),
(52, 'storefront-customize', 'info', 'en_US', 'Design your store with Storefront 🎨', 'Visit the Storefront settings page to start setup and customization of your shop.', '[]', 'unactioned', 'storefront', '2023-04-19 13:21:26', NULL, 0, 'plain', '', 0, 1, 'info'),
(53, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Välj ett tema?', 'Kolla in olika teman som är kompatibla med WooCommerce och välj ett som passar ihop med ditt varumärke och dina företagsbehov.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 13:21:23', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'wc-admin-launch-checklist', 'info', 'en_US', 'Är du redo att lansera din butik?', 'Vi har sammanställt en omfattande checklista innan webbplatsen tas i bruk så att du aldrig får känslan av att ha glömt något.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 13:21:23', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'wc-admin-customizing-product-catalog', 'info', 'en_US', 'Så här anpassar du din produktkatalog', 'Du vill att din produktkatalog och dina bilder ska se fantastiska ut och vara i linje med ditt varumärke. Den här guiden ger dig alla tips du behöver för att få dina produkter att se fantastiska ut i din butik.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-24 07:32:31', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'wc-admin-mobile-app', 'info', 'en_US', 'Installera Woo-mobilappen', 'Installera WooCommerce-mobilappen och hantera beställningar, få säljnotiser och granska nyckeltal – var som helst.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-24 07:32:31', NULL, 0, 'plain', '', 0, 0, 'info'),
(57, 'wc-admin-online-clothing-store', 'info', 'en_US', 'Starta din klädbutik online', 'Att starta en modewebbplats är spännande men det kan även kännas överväldigande ibland. I den här artikeln tar vi dig igenom konfigurationsprocessen, lär dig hur du skapar lyckade produktlistningar och visar dig hur du marknadsför mot din perfekta målgrupp.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-24 07:32:31', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_category_lookup`
#
INSERT INTO `wp_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(15, 15),
(24, 24),
(24, 26),
(24, 27),
(25, 25),
(25, 28),
(25, 29),
(26, 26),
(27, 27),
(28, 28),
(29, 29),
(32, 32) ;

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_stats`
#

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#
INSERT INTO `wp_wc_product_attributes_lookup` ( `product_id`, `product_or_parent_id`, `taxonomy`, `term_id`, `is_variation_attribute`, `in_stock`) VALUES
(32, 25, 'pa_storlek', 18, 1, 1),
(31, 25, 'pa_storlek', 19, 1, 1),
(30, 25, 'pa_storlek', 20, 1, 1),
(34, 33, 'pa_farg', 16, 1, 1),
(35, 33, 'pa_farg', 16, 1, 1),
(36, 33, 'pa_farg', 16, 1, 1),
(37, 33, 'pa_farg', 17, 1, 1),
(38, 33, 'pa_farg', 17, 1, 1),
(39, 33, 'pa_farg', 17, 1, 1),
(36, 33, 'pa_storlek', 18, 1, 1),
(39, 33, 'pa_storlek', 18, 1, 1),
(35, 33, 'pa_storlek', 19, 1, 1),
(38, 33, 'pa_storlek', 19, 1, 1),
(34, 33, 'pa_storlek', 20, 1, 1),
(37, 33, 'pa_storlek', 20, 1, 1),
(42, 41, 'pa_vikt', 21, 1, 1),
(43, 41, 'pa_vikt', 22, 1, 1),
(44, 41, 'pa_vikt', 23, 1, 1) ;

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file://C:/MAMP/htdocs/labb2-linus/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost/labb2-linus/wp-content/uploads/woocommerce_uploads/', 1),
(3, 'http://localhost/labb2-linus/wp-content/uploads/2023/04/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(25, '', 0, 0, '399.0000', '399.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(30, 'yogatights-large', 0, 0, '399.0000', '399.0000', 0, '7', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(31, 'yogatights-medium', 0, 0, '399.0000', '399.0000', 0, '3', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(32, 'yogatights-small', 0, 0, '399.0000', '399.0000', 0, '9', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(33, '', 0, 0, '299.0000', '399.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(34, 'traningstopp-pink-large', 0, 0, '399.0000', '399.0000', 0, '3', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(35, 'traningstopp-pink-medium', 0, 0, '399.0000', '399.0000', 0, '3', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(36, 'traningstopp-pink-small', 0, 0, '399.0000', '399.0000', 0, '9', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(37, 'traningstopp-black-large', 0, 0, '299.0000', '299.0000', 1, '3', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(38, 'traningstopp-black-medium', 0, 0, '299.0000', '299.0000', 1, '2', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(39, 'traningstopp-black-small', 0, 0, '299.0000', '299.0000', 1, '11', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(40, 'yogamatta', 0, 0, '399.0000', '399.0000', 0, '5', 'instock', 0, '0.00', 0, 'taxable', ''),
(41, '', 0, 0, '149.0000', '299.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(42, 'hantel-2kg', 0, 0, '149.0000', '149.0000', 0, '7', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(43, 'hantel-4kg', 0, 0, '249.0000', '249.0000', 0, '9', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(44, 'hantel-5kg', 0, 0, '299.0000', '299.0000', 0, '2', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(45, 'traningsschema', 0, 1, '29.0000', '29.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#
INSERT INTO `wp_woocommerce_attribute_taxonomies` ( `attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'farg', 'Färg', 'select', 'menu_order', 0),
(2, 'storlek', 'Storlek', 'select', 'menu_order', 0),
(3, 'vikt', 'Vikt', 'select', 'menu_order', 0) ;

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(2, '1', 'a:8:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:766:"a:27:{s:2:"id";s:1:"1";s:13:"date_modified";s:25:"2023-04-20T14:32:24+02:00";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"SE";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"SE";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:23:"lundell.linus@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";s:10:"wc_notices";N;}', 1682519069) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#
INSERT INTO `wp_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'SE', 'country') ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#
INSERT INTO `wp_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1),
(1, 2, 'flat_rate', 2, 1) ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#
INSERT INTO `wp_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Sweden', 0) ;

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#
INSERT INTO `wp_woocommerce_tax_rates` ( `tax_rate_id`, `tax_rate_country`, `tax_rate_state`, `tax_rate`, `tax_rate_name`, `tax_rate_priority`, `tax_rate_compound`, `tax_rate_shipping`, `tax_rate_order`, `tax_rate_class`) VALUES
(1, 'SE', '', '25.0000', '25% moms', 1, 0, 1, 0, '') ;

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

